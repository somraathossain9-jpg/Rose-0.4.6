package app.shilex.android.audio

import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Talking over a reply on the loudspeaker. Every mic chunk is cleaned against what the
 * speaker played (EchoCanceller); while the reply plays, the mic stays muted unless the
 * cleaned audio holds a voice for [chunks] chunks in a row (100 ms each). Then the reply is
 * cut and those chunks go to Gemini, so the start of what was said isn't lost.
 *
 * The canceller needs time to learn the echo; until it removes most of it (measured on
 * chunks without a voice), talk-over stays off and the mic stays muted. Within a conversation
 * what it learned carries over, but each reply needs a few echo chunks first; a new
 * conversation starts unproven.
 */
class TalkOver(
    private val speaker: Speaker,
    private val level: Int = VOICE,
    private val chunks: Int = CHUNKS,
    private val learnChunks: Int = LEARN_CHUNKS,
    private val goodAttenuation: Double = GOOD_ATTENUATION,
) {
    private val aec = EchoCanceller.create()
    private val mic = ShortArray(EchoCanceller.CHUNK)
    private val ref = ShortArray(EchoCanceller.CHUNK)
    private val held = ArrayDeque<ByteArray>()
    private var attenuation = 1.0 // cleaned / raw loudness, averaged over echo-only chunks
    private var echoChunks = 0
    private var chunk = 0
    private var readyAt = -1
    private var echoFloor = 0.0 // the loudest echo lately (raw mic level while no voice), slowly fading

    /** When talk-over became possible in this reply, in ms (or -1: never). */
    val readyAfterMs: Int get() = if (readyAt < 0) -1 else readyAt * 100

    /** The canceller removes the echo well enough to tell a voice from it. */
    val ready: Boolean get() = echoChunks >= learnChunks && attenuation < goodAttenuation

    val available: Boolean get() = aec != null

    /** Loudest chunk before and after cleaning while the reply played (for tuning). */
    var rawPeak = 0
        private set
    var cleanPeak = 0
        private set

    /** The mic chunk with the reply's echo removed (unchanged without the canceller). */
    fun clean(pcm: ByteArray): ByteArray {
        val canceller = aec ?: return pcm
        if (pcm.size != EchoCanceller.CHUNK * 2) return pcm
        ByteBuffer.wrap(pcm).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(mic)
        speaker.reference(ref, REF_BACK)
        canceller.process(mic, ref)
        return ByteArray(pcm.size).also { ByteBuffer.wrap(it).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(canceller.cleaned) }
    }

    /** A cleaned chunk while the reply plays: null keeps the mic muted; else the voice so far. */
    fun duringReply(raw: ByteArray, cleaned: ByteArray): List<ByteArray>? {
        val before = pcmLevel(raw)
        val after = pcmLevel(cleaned)
        if (before > rawPeak) rawPeak = before
        // A voice passes the canceller nearly whole; leftover echo is cut like the rest of the
        // reply (to about [attenuation] of its level), so a voice is clearly above that.
        val voice = after >= level && after >= before * maxOf(VOICE_KEPT, 2 * attenuation)
        if (ready && readyAt < 0) readyAt = chunk
        // 0.4.1: the canceller may never "learn" on some phones (quiet or distorted speaker), and then talking
        // over the reply did nothing at all. Until it has, a voice is also recognised by its level: the mic
        // suddenly well above the echo heard so far, for a few chunks in a row. The raw audio is passed on then.
        val spike = !ready && chunk >= WARM_CHUNKS && before >= 1.5 * level && before >= SPIKE_RATIO * echoFloor
        if (!spike) echoFloor = maxOf(echoFloor * FLOOR_DECAY, before.toDouble())
        chunk++
        val cancelled = voice && ready
        if (!cancelled && !spike) {
            if (after > cleanPeak) cleanPeak = after
            if (before > ECHO_LEVEL) {
                attenuation = 0.7 * attenuation + 0.3 * (after.toDouble() / before)
                echoChunks++
            }
            held.clear()
            return null
        }
        held.addLast(if (cancelled) cleaned else raw)
        if (held.size < if (cancelled) chunks else maxOf(chunks, SPIKE_CHUNKS)) return null
        return held.toList().also { held.clear() }
    }

    /** A new reply: a few echo chunks before talk-over; [newConversation] forgets the rest. */
    fun reset(newConversation: Boolean = false) {
        held.clear()
        if (newConversation) attenuation = 1.0
        echoChunks = if (newConversation) 0 else maxOf(0, learnChunks - REPLY_CHUNKS)
        chunk = 0
        echoFloor = 0.0
        readyAt = -1
        rawPeak = 0
        cleanPeak = 0
    }

    fun close() {
        aec?.close()
    }

    companion object {
        const val VOICE = 1_000
        const val CHUNKS = 3
        /** Phone-friendly values: react to a voice sooner, accept a less perfect echo canceller. */
        const val QUICK_VOICE = 500
        const val QUICK_CHUNKS = 1
        const val QUICK_LEARN_CHUNKS = 3
        const val QUICK_ATTENUATION = 0.4
        private const val VOICE_KEPT = 0.35
        private const val WARM_CHUNKS = 2 // 0.4.3: the first 200 ms of a reply only measure the echo
        private const val SPIKE_RATIO = 1.6 // 0.4.3: a voice is at least 1.6 times the echo heard so far
        private const val SPIKE_CHUNKS = 2 // 0.4.3: and lasts 200 ms (was 300)
        private const val FLOOR_DECAY = 0.98
        private const val ECHO_LEVEL = 800 // loud enough to judge the canceller by
        private const val LEARN_CHUNKS = 5
        private const val REPLY_CHUNKS = 3 // echo chunks each later reply needs first
        private const val GOOD_ATTENUATION = 0.25 // echo at least about 12 dB quieter
        // Reference ends 60 ms before what's playing now, so the echo always comes after it.
        private const val REF_BACK = EchoCanceller.RATE * 60 / 1000
    }
}
