package app.shilex.android.chat

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import app.shilex.android.Diag
import java.util.Locale

/**
 * 0.4.6: reads a chat answer aloud with the phone's own voice (the Chat tab's Speaker button and the Listen button on a
 * message). Bangla text is read with a Bangla voice when the phone has one, everything else in English (India).
 * Nothing leaves the phone.
 */
object ChatVoice {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ready = false
    private var waiting: String? = null

    private val BANGLA = Regex("[\\u0980-\\u09FF]")
    private val MARKDOWN = Regex("[*_`#>~|]+")

    /** The text without markdown marks and long code, so it sounds like speech. */
    fun clean(text: String): String = text
        .replace(Regex("```[\\s\\S]*?```"), " ")
        .replace(MARKDOWN, " ")
        .replace(Regex("\\s+"), " ")
        .trim()
        .take(MAX_CHARS)

    fun speak(context: Context, text: String) {
        val line = clean(text)
        if (line.isEmpty()) return
        val app = context.applicationContext
        main.post {
            val voice = tts
            if (voice != null && ready) {
                say(voice, line)
            } else {
                waiting = line
                if (voice == null) open(app)
            }
        }
    }

    fun stop() {
        main.post {
            waiting = null
            if (ready) tts?.stop()
        }
    }

    private fun say(voice: TextToSpeech, line: String) {
        val bangla = BANGLA.containsMatchIn(line)
        val bn = Locale("bn", "BD")
        voice.language = if (bangla && voice.isLanguageAvailable(bn) >= TextToSpeech.LANG_AVAILABLE) bn else Locale("en", "IN")
        voice.speak(line, TextToSpeech.QUEUE_FLUSH, null, "chat")
    }

    private fun open(context: Context) {
        lateinit var voice: TextToSpeech
        voice = TextToSpeech(context) { status ->
            main.post {
                if (status != TextToSpeech.SUCCESS) {
                    Diag.w("chat voice: no voice on this phone")
                    tts = null
                    waiting = null
                    return@post
                }
                ready = true
                waiting?.let { say(voice, it) }
                waiting = null
            }
        }
        tts = voice
    }

    private const val MAX_CHARS = 3_500
}
