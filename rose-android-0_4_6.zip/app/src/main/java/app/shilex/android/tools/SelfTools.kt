package app.shilex.android.tools

import android.content.Context
import android.os.PowerManager
import androidx.core.app.NotificationManagerCompat
import app.shilex.android.DiagFile
import app.shilex.android.control.ControlService
import app.shilex.android.data.KeyVault
import app.shilex.android.data.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Rose says what she cannot do and where she is weak, and remembers the updates she wishes for. */
object SelfTools {
    fun all(): List<PhoneTool> = listOf(ReportLimit, SelfCheck)

    /** Things that are true of this app and not fixable by a setting. Kept short and honest. */
    private val KNOWN_LIMITS = listOf(
        "Talking over my reply on the loudspeaker can still miss on some phones; headphones are the reliable way.",
        "I cannot make videos. I can write a prompt for a video tool, and I can make pictures.",
        "I can read messages from any chat app, but I can only answer chats that show a Reply box in the notification.",
        "I cannot test the code I write on this phone; the GitHub build is the test.",
        "Android can stop background apps on some phones, so message alerts can be late there unless battery saving is off for me.",
    )

    private fun wishes(context: Context) = context.getSharedPreferences("self_notes", Context.MODE_PRIVATE)

    fun wishList(context: Context): List<String> {
        val raw = wishes(context).getString("list", "[]") ?: "[]"
        val array = runCatching { JSONArray(raw) }.getOrDefault(JSONArray())
        return (0 until array.length()).map { array.optString(it) }
    }

    private object ReportLimit : PhoneTool {
        override val name = "report_limit"

        override fun declaration() = Schema.function(
            name,
            "Saves a limit you hit: something the owner asked that you cannot do, or a weakness you noticed, and the update that would fix it. " +
                "Call it, then tell the owner in your own words and ask whether to update. Changes nothing else.",
            Schema.string("what", "What you could not do or what is weak.", required = true),
            Schema.string("fix", "The update that would fix it.", required = true),
        )

        override suspend fun run(args: JSONObject, host: ToolHost): JSONObject {
            val line = (args.text("what") + " -> " + args.text("fix")).take(300)
            val list = (wishList(host.context) + line).takeLast(30)
            wishes(host.context).edit().putString("list", JSONArray(list).toString()).apply()
            return Results.done(
                "Saved. Now tell the owner what you cannot do and what update would help, and ask \"update kore dibo?\". " +
                    "Do nothing more unless he says yes.",
            )
        }
    }

    private object SelfCheck : PhoneTool {
        override val name = "self_check"

        override fun declaration() = Schema.function(
            name,
            "Checks yourself: which permissions and connections are missing, recent warnings from the diagnostic log, " +
                "known weaknesses and the updates you wished for. Use it when the owner asks about your problems or weaknesses.",
        )

        override suspend fun run(args: JSONObject, host: ToolHost): JSONObject {
            val c = host.context
            val settings = Settings(c)
            val missing = mutableListOf<String>()
            if (KeyVault(c).read(KeyVault.GEMINI_KEY) == null) missing += "No Gemini key."
            if (c.packageName !in NotificationManagerCompat.getEnabledListenerPackages(c)) missing += "Notification access is off, so I cannot see messages."
            if (ControlService.instance == null) missing += "Phone control is off, so I cannot tap in apps and cannot show Allow cards (pushes and installs need them)."
            if (!android.provider.Settings.canDrawOverlays(c)) missing += "Display over other apps is off, so no floating orb."
            if (!c.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(c.packageName)) missing += "Battery saving may stop me in the background."
            if (KeyVault(c).read(KeyVault.GITHUB_TOKEN).isNullOrBlank() || settings.githubRepo.isBlank()) missing += "GitHub is not set up (repo and token in Settings)."
            if (!c.packageManager.canRequestPackageInstalls()) missing += "I am not allowed to install my own updates yet."
            return Results.done("Report this honestly and briefly, most important first.")
                .put("missing", JSONArray(missing))
                .put("recent_warnings", JSONArray(recentWarnings(c)))
                .put("known_limits", JSONArray(KNOWN_LIMITS))
                .put("wished_updates", JSONArray(wishList(c)))
        }
    }

    /** The last few distinct warnings from the diagnostic file (it holds states and timings, never words). */
    private fun recentWarnings(context: Context): List<String> {
        val file = File(context.filesDir, DiagFile.NAME)
        if (!file.exists()) return emptyList()
        val tail = runCatching { file.readText().takeLast(60_000) }.getOrDefault("")
        return tail.lines().filter { it.contains(" W ") }
            .map { it.substringAfter(" W ", it).take(160) }.distinct().takeLast(6)
    }
}
