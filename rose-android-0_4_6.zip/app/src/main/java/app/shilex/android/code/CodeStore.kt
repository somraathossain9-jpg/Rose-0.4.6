package app.shilex.android.code

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Which file names the code workspace accepts. Pure, so it is unit-tested. */
object CodePaths {
    const val MAX_FILE = 300_000
    const val MAX_FILES = 800
    private val BAD = Regex("[\\u0000-\\u001f:*?\"<>|]")

    /** A safe relative path ("app/src/Main.kt"), or null when it could leave the workspace or touch .git. */
    fun clean(raw: String): String? {
        val path = raw.trim().replace('\\', '/').trimStart('/')
        if (path.isEmpty() || path.length > 200 || BAD.containsMatchIn(path)) return null
        val parts = path.split('/')
        if (parts.any { it.isEmpty() || it == "." || it == ".." || it == ".git" }) return null
        return parts.joinToString("/")
    }
}

/**
 * The code Rose writes lives here, in the app's private files (nothing else on the phone is
 * reachable). Tools write files into it, zip it, and push it to GitHub after the owner's Allow.
 */
class CodeStore(context: Context) {
    private val root = File(context.filesDir, "rose-code").apply { mkdirs() }
    private val rootPath = root.canonicalPath

    private fun file(path: String): File? {
        val clean = CodePaths.clean(path) ?: return null
        val f = File(root, clean)
        return if (f.canonicalPath.startsWith("$rootPath/")) f else null
    }

    /** Null when written, else why not. */
    fun write(path: String, content: String): String? = writeBytes(path, content.toByteArray(Charsets.UTF_8))

    fun writeBytes(path: String, bytes: ByteArray): String? {
        val f = file(path) ?: return "That file name is not allowed."
        if (bytes.size > CodePaths.MAX_FILE) return "That file is too big (limit ${CodePaths.MAX_FILE / 1000} KB)."
        if (!f.exists() && list().size >= CodePaths.MAX_FILES) return "Too many files (limit ${CodePaths.MAX_FILES})."
        f.parentFile?.mkdirs()
        f.writeBytes(bytes)
        return null
    }

    fun read(path: String): String? = file(path)?.takeIf { it.isFile }?.readText(Charsets.UTF_8)

    fun delete(path: String): Boolean = file(path)?.takeIf { it.isFile }?.delete() == true

    fun clear() {
        root.deleteRecursively()
        root.mkdirs()
    }

    /** Relative path and size of every file, sorted. */
    fun list(): List<Pair<String, Long>> = root.walkTopDown().filter { it.isFile }
        .map { it.relativeTo(root).path.replace('\\', '/') to it.length() }
        .sortedBy { it.first }
        .toList()

    fun bytes(path: String): ByteArray? = file(path)?.takeIf { it.isFile }?.readBytes()

    /** Every file as a zip, under a top folder called [folder]. */
    fun zip(folder: String): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            list().forEach { (path, _) ->
                zip.putNextEntry(ZipEntry("$folder/$path"))
                zip.write(File(root, path).readBytes())
                zip.closeEntry()
            }
        }
        return out.toByteArray()
    }
}

/** Saves a file where the owner can open it: Downloads/Rose or Pictures/Rose (no permission needed). */
object PublicFiles {
    fun saveDownload(context: Context, name: String, mime: String, bytes: ByteArray): Boolean =
        save(context, MediaStore.Downloads.EXTERNAL_CONTENT_URI, name, mime, bytes, Environment.DIRECTORY_DOWNLOADS + "/Rose")

    fun savePicture(context: Context, name: String, mime: String, bytes: ByteArray): Boolean =
        save(context, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, name, mime, bytes, Environment.DIRECTORY_PICTURES + "/Rose")

    private fun save(context: Context, collection: android.net.Uri, name: String, mime: String, bytes: ByteArray, folder: String): Boolean {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, folder)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(collection, values) ?: return false
        return runCatching { resolver.openOutputStream(uri)?.use { it.write(bytes) } != null }.getOrDefault(false)
    }
}
