package app.shilex.android.tools

import app.shilex.android.control.ControlService

/**
 * The owner's Allow for pushes, installs and other changes outside the phone. It is ROSE's own
 * on-screen card, which only a finger can press (the same card phone control uses), so a
 * fooled model can't approve for itself. Without Phone control there is no card: not allowed.
 */
object Approval {
    /**
     * 0.4.6: while the Chat screen is open it shows its own Allow dialog here, so Rose can push and update from the
     * chat without Phone control. Still only a finger can press it. Null again when the chat screen is closed.
     */
    @Volatile var screenAsker: (suspend (String) -> Boolean)? = null

    /** True only if the owner pressed Allow; false if not; null when no card can be shown. */
    suspend fun ask(what: String): Boolean? {
        screenAsker?.let { return it(what) }
        val overlay = ControlService.instance?.overlay?.takeUnless { it.stopped } ?: return null
        return overlay.confirm(what)
    }

    /** Null when allowed, else the tool result to return. */
    suspend fun gate(what: String): org.json.JSONObject? = when (ask(what)) {
        true -> null
        false -> DECLINED
        null -> NO_CARD
    }

    val NO_CARD = Results.failed(
        "no_allow_card",
        "No Allow card could be shown. Tell the owner to open the Chat tab in ROSE (it shows its own Allow button) or turn on Phone control in Settings, then ask again. Nothing was done.",
    )

    val DECLINED = Results.failed("not_allowed", "The owner did not press Allow. Nothing was done; do not try another way.")
}
