package app.shilex.android.data

import android.content.Context
import android.content.SharedPreferences

/** Plain preferences (no secrets). Defaults match the desktop app. */
class Settings(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var model: String
        get() = prefs.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(value) = prefs.edit().putString("model", value).apply()

    var voice: String
        get() = prefs.getString("voice", DEFAULT_VOICE) ?: DEFAULT_VOICE
        set(value) = prefs.edit().putString("voice", value).apply()

    /** "bengali" (Bangla script, default), "banglish" (Bangla in English letters) or "english". Hindi was removed in 0.4.3. */
    var replyLanguage: String
        get() = when (val saved = prefs.getString("reply_language", "bengali") ?: "bengali") {
            "bengali", "banglish", "english" -> saved
            else -> "bengali" // old values (auto, hindi, hinglish) become Bangla
        }
        set(value) = prefs.edit().putString("reply_language", value).apply()

    /** Now and then a playful English line (movie-style), made up from what is being talked about. */
    var englishFun: Boolean
        get() = prefs.getBoolean("english_fun", true)
        set(value) = prefs.edit().putBoolean("english_fun", value).apply()

    /** "owner/repo" that the GitHub tools may touch, e.g. "somraat/rose-android". Nothing else is reachable. */
    var githubRepo: String
        get() = prefs.getString("github_repo", "") ?: ""
        set(value) = prefs.edit().putString("github_repo", value.trim()).apply()

    /** The branch Rose pushes to; she never pushes to main or master. */
    var githubBranch: String
        get() = prefs.getString("github_branch", DEFAULT_BRANCH) ?: DEFAULT_BRANCH
        set(value) = prefs.edit().putString("github_branch", value.trim().ifEmpty { DEFAULT_BRANCH }).apply()

    /** 0.4.6: read ROSE's chat answers aloud in the Chat tab (the Speaker button). */
    var chatSpeaker: Boolean
        get() = prefs.getBoolean("chat_speaker", false)
        set(value) = prefs.edit().putBoolean("chat_speaker", value).apply()

    /** The text model for the "brain" (code, prompts, plans) and the picture model. Plain Gemini model names. */
    var brainModel: String
        get() = prefs.getString("brain_model", DEFAULT_BRAIN) ?: DEFAULT_BRAIN
        set(value) = prefs.edit().putString("brain_model", value.trim().ifEmpty { DEFAULT_BRAIN }).apply()

    /** The model for the text chat screen (it needs generateContent, so not the Live model). */
    var chatModel: String
        get() = prefs.getString("chat_model", DEFAULT_CHAT) ?: DEFAULT_CHAT
        set(value) = prefs.edit().putString("chat_model", value.trim().ifEmpty { DEFAULT_CHAT }).apply()

    var imageModel: String
        get() = prefs.getString("image_model", DEFAULT_IMAGE) ?: DEFAULT_IMAGE
        set(value) = prefs.edit().putString("image_model", value.trim().ifEmpty { DEFAULT_IMAGE }).apply()

    /**
     * Let ROSE press Send / Call itself in messaging apps and the dialer, without the Allow card.
     * Off by default. Money, delete, passwords, OTP and banking apps are never covered (control/ControlRules).
     */
    var autoAllowMessaging: Boolean
        get() = prefs.getBoolean("auto_allow_messaging", false)
        set(value) = prefs.edit().putBoolean("auto_allow_messaging", value).apply()

    /** Friendly, joking personality that calls the owner by name (assistant/Instructions). */
    var friendly: Boolean
        get() = prefs.getBoolean("friendly", true)
        set(value) = prefs.edit().putBoolean("friendly", value).apply()

    /**
     * Messages from people: "off", "ask" (read each one aloud and ask whether to reply) or
     * "auto" (busy mode: answer by itself as the owner's assistant, see notify/AutoReply).
     */
    var autoReplyMode: String
        get() = prefs.getString("auto_reply_mode", "off") ?: "off"
        set(value) = prefs.edit().putString("auto_reply_mode", value).apply()

    /** Optional line for busy mode, e.g. "he will call back at 5". */
    var autoReplyNote: String
        get() = prefs.getString("auto_reply_note", "") ?: ""
        set(value) = prefs.edit().putString("auto_reply_note", value).apply()

    /** The battery-optimisation prompt was shown once (it keeps message alerts instant). */
    var batteryAsked: Boolean
        get() = prefs.getBoolean("battery_asked", false)
        set(value) = prefs.edit().putBoolean("battery_asked", value).apply()

    /** Mute the mic while the assistant speaks, unless headphones are in use. */
    var halfDuplex: Boolean
        get() = prefs.getBoolean("half_duplex", true)
        set(value) = prefs.edit().putBoolean("half_duplex", value).apply()

    /** Talk over a reply on the loudspeaker (audio/TalkOver, with the echo canceller). */
    var talkOver: Boolean
        get() = prefs.getBoolean("talk_over", true)
        set(value) = prefs.edit().putBoolean("talk_over", value).apply()

    /** Wave over the proximity sensor to cut a reply off (audio/WaveStop). */
    var waveToStop: Boolean
        get() = prefs.getBoolean("wave_to_stop", true)
        set(value) = prefs.edit().putBoolean("wave_to_stop", value).apply()

    /** Listen on the phone for the wake phrase between sessions (debug builds only for now). */
    var wakeWord: Boolean
        get() = prefs.getBoolean("wake_word", false)
        set(value) = prefs.edit().putBoolean("wake_word", value).apply()

    /** After the wake word, simple commands run on the phone (no Gemini) when it can hear them. */
    var localCommands: Boolean
        get() = prefs.getBoolean("local_commands", true)
        set(value) = prefs.edit().putBoolean("local_commands", value).apply()

    /**
     * Let local commands use the phone's network speech service when it has no on-device one.
     * Off by default: that service sends the audio to its provider (usually Google).
     */
    var networkSpeech: Boolean
        get() = prefs.getBoolean("network_speech", false)
        set(value) = prefs.edit().putBoolean("network_speech", value).apply()

    /** Learn on the phone how this user uses ROSE (learn/Habits). */
    var learning: Boolean
        get() = prefs.getBoolean("learning", true)
        set(value) = prefs.edit().putBoolean("learning", value).apply()

    /** The first-run setup was finished (or skipped) once. */
    var onboarded: Boolean
        get() = prefs.getBoolean("onboarded", false)
        set(value) = prefs.edit().putBoolean("onboarded", value).apply()

    /** The floating orb over other apps (needs "Display over other apps"). */
    var floatingOrb: Boolean
        get() = prefs.getBoolean("floating_orb", false)
        set(value) = prefs.edit().putBoolean("floating_orb", value).apply()

    /** Where the user last left the floating orb, in screen pixels; -1 = not moved yet. */
    var orbX: Int
        get() = prefs.getInt("orb_x", -1)
        set(value) = prefs.edit().putInt("orb_x", value).apply()

    var orbY: Int
        get() = prefs.getInt("orb_y", -1)
        set(value) = prefs.edit().putInt("orb_y", value).apply()

    /** The last city asked about; weather questions without a city use it. */
    var homeCity: String
        get() = prefs.getString("home_city", "") ?: ""
        set(value) = prefs.edit().putString("home_city", value).apply()

    /** Calls [onChange] after any setting changes, from any screen or the notification. */
    fun watch(onChange: () -> Unit): SharedPreferences.OnSharedPreferenceChangeListener =
        SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> onChange() }
            .also(prefs::registerOnSharedPreferenceChangeListener)

    fun unwatch(listener: SharedPreferences.OnSharedPreferenceChangeListener) =
        prefs.unregisterOnSharedPreferenceChangeListener(listener)

    val speechLanguages: List<String> = listOf("bn-IN", "en-IN")

    companion object {
        const val DEFAULT_MODEL = "gemini-3.1-flash-live-preview"
        const val DEFAULT_VOICE = "Kore"
        const val DEFAULT_BRANCH = "rose-work"
        const val DEFAULT_BRAIN = "gemini-2.5-pro"
        const val DEFAULT_CHAT = "gemini-2.5-flash"
        const val DEFAULT_IMAGE = "gemini-2.5-flash-image"

        /** Gemini Live's female prebuilt voices, then a few male ones. */
        val VOICES = listOf(
            "Kore", "Aoede", "Leda", "Zephyr", "Autonoe", "Callirrhoe", "Despina", "Achernar", "Gacrux", "Sulafat",
            "Puck", "Charon", "Fenrir", "Orus",
        )
    }
}
