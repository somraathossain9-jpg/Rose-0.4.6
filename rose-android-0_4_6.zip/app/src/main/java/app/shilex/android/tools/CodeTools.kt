package app.shilex.android.tools

import app.shilex.android.Diag
import app.shilex.android.code.CodePaths
import app.shilex.android.code.CodeStore
import app.shilex.android.code.PublicFiles
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Rose's code workspace on the phone: she writes files, reads them back and zips them (saved to Downloads/Rose).
 * Only this one folder is reachable; names are checked (CodePaths). Pushing to GitHub is a separate tool with an Allow card.
 */
object CodeTools {
    fun all(): List<PhoneTool> = listOf(Write, Read, ListFiles, Delete, Zip, Replace, Search)

    private object Write : PhoneTool {
        override val name = "code_write"

        override fun declaration() = Schema.function(
            name,
            "Writes (or replaces) one file in the code workspace on the phone: source code, a build YAML, a README. " +
                "Give the whole file. Use short relative paths like app/src/main/java/app/shilex/android/Foo.kt or .github/workflows/build.yml.",
            Schema.string("path", "Relative file path.", required = true),
            Schema.string("content", "The complete text of the file.", required = true),
        )

        override suspend fun run(args: JSONObject, host: ToolHost): JSONObject {
            val path = args.text("path")
            if (CodePaths.clean(path) == null) return Results.failed("bad_path", "That file name is not allowed.")
            val content = args.optString("content")
            if (app.shilex.android.code.GitHubRules.looksSecret(content)) {
                return Results.failed("secret", "That file looks like it holds a key, token, PIN, OTP or password. It is not saved. Tell the owner, and keep such things out of code.")
            }
            val problem = CodeStore(host.context).write(path, content)
            Diag.i("code: wrote a file (${content.length} chars)")
            return problem?.let { Results.failed("not_written", it) } ?: Results.done("Wrote $path (${content.length} characters).")
        }
    }

    /** 0.4.6: change a few lines of a big file without sending the whole file again. */
    private object Replace : PhoneTool {
        override val name = "code_replace"

        override fun declaration() = Schema.function(
            name,
            "Changes one file in the code workspace by replacing a piece of its text: old_text (copied exactly from code_read, " +
                "it must appear exactly once) becomes new_text. Use this for small edits instead of code_write.",
            Schema.string("path", "Relative file path.", required = true),
            Schema.string("old_text", "The exact text to replace (must appear once).", required = true),
            Schema.string("new_text", "The text that goes there (may be empty to delete).", required = true),
        )

        override suspend fun run(args: JSONObject, host: ToolHost): JSONObject {
            val path = args.text("path")
            val store = CodeStore(host.context)
            val old = store.read(path) ?: return Results.failed("not_found", "No such file in the workspace. Use github_pull first, or code_list.")
            val from = args.optString("old_text")
            val to = args.optString("new_text")
            if (from.isEmpty()) return Results.failed("no_old", "old_text is empty.")
            val first = old.indexOf(from)
            if (first < 0) return Results.failed("not_found_text", "That text is not in $path. Read the file again with code_read and copy it exactly.")
            if (old.indexOf(from, first + 1) >= 0) return Results.failed("not_unique", "That text appears more than once in $path. Add a few more lines around it so it is unique.")
            val changed = old.substring(0, first) + to + old.substring(first + from.length)
            if (app.shilex.android.code.GitHubRules.looksSecret(to)) {
                return Results.failed("secret", "The new text looks like it holds a key, token, PIN, OTP or password. Not saved.")
            }
            val problem = store.write(path, changed)
            Diag.i("code: edited a file")
            return problem?.let { Results.failed("not_written", it) } ?: Results.done("Changed $path.")
        }
    }

    /** 0.4.6: find where something is in the project without reading every file. */
    private object Search : PhoneTool {
        override val name = "code_search"

        override fun declaration() = Schema.function(
            name,
            "Searches the code workspace for a word or phrase (not case sensitive). Returns file, line number and the line, " +
                "at most 40 matches. Use it to find where to make a change.",
            Schema.string("text", "What to look for.", required = true),
        )

        override suspend fun run(args: JSONObject, host: ToolHost): JSONObject {
            val needle = args.text("text").lowercase()
            if (needle.length < 2) return Results.failed("short", "Give at least two letters to search for.")
            val store = CodeStore(host.context)
            val hits = JSONArray()
            for ((path, size) in store.list()) {
                if (hits.length() >= 40) break
                if (size > CodePaths.MAX_FILE || !app.shilex.android.code.GitHubRules.isText(path)) continue
                val lines = store.read(path)?.lines() ?: continue
                for ((i, line) in lines.withIndex()) {
                    if (line.lowercase().contains(needle)) {
                        hits.put("$path:${i + 1}: ${line.trim().take(160)}")
                        if (hits.length() >= 40) break
                    }
                }
            }
            return Results.done(if (hits.length() == 0) "No match." else "${hits.length()} match(es).").put("matches", hits)
        }
    }

    private object Read : PhoneTool {
        override val name = "code_read"

        override fun declaration() = Schema.function(
            name,
            "Reads one file from the code workspace (20000 characters at a time; use start for the next part).",
            Schema.string("path", "Relative file path.", required = true),
            Schema.integer("start", "Character to start from; default 0."),
        )

        override suspend fun run(args: JSONObject, host: ToolHost): JSONObject {
            val text = CodeStore(host.context).read(args.text("path"))
                ?: return Results.failed("not_found", "No such file in the workspace. Use github_pull first, or code_list.")
            val from = args.optInt("start", 0).coerceIn(0, text.length)
            val part = text.substring(from, minOf(text.length, from + 20_000))
            return Results.done(part).put("truncated", from + part.length < text.length).put("next_start", from + part.length)
        }
    }

    private object ListFiles : PhoneTool {
        override val name = "code_list"

        override fun declaration() = Schema.function(name, "Lists the files in the code workspace with their sizes.")

        override suspend fun run(args: JSONObject, host: ToolHost): JSONObject {
            val files = CodeStore(host.context).list()
            val shown = JSONArray(files.take(150).map { "${it.first} (${it.second} bytes)" })
            return Results.done(if (files.isEmpty()) "The workspace is empty." else "${files.size} files.")
                .put("files", shown).put("more", (files.size - 150).coerceAtLeast(0))
        }
    }

    private object Delete : PhoneTool {
        override val name = "code_delete"

        override fun declaration() = Schema.function(
            name,
            "Deletes one file from the code workspace. Only when the owner asked.",
            Schema.string("path", "Relative file path.", required = true),
        )

        override suspend fun run(args: JSONObject, host: ToolHost): JSONObject =
            if (CodeStore(host.context).delete(args.text("path"))) Results.done("Deleted.") else Results.failed("not_found", "No such file.")
    }

    private object Zip : PhoneTool {
        override val name = "code_zip"

        override fun declaration() = Schema.function(
            name,
            "Packs every file in the code workspace into a zip and saves it in the phone's Downloads/Rose folder. " +
                "Name it like rose-android-0.4.6 (letters, digits, dots and dashes).",
            Schema.string("name", "Zip name without .zip.", required = true),
        )

        override suspend fun run(args: JSONObject, host: ToolHost): JSONObject {
            val name = args.text("name").replace(Regex("[^A-Za-z0-9._-]"), "-").trim('-', '.').take(60)
            if (name.isEmpty()) return Results.failed("bad_name", "Give the zip a name.")
            val store = CodeStore(host.context)
            if (store.list().isEmpty()) return Results.failed("empty", "The workspace is empty, so there is nothing to zip.")
            val bytes = store.zip(name)
            val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
            val file = "$name-$stamp.zip"
            return if (PublicFiles.saveDownload(host.context, file, "application/zip", bytes)) {
                Results.done("Saved $file (${bytes.size / 1024} KB) in the Downloads/Rose folder.")
            } else {
                Results.failed("not_saved", "The phone would not save the zip.")
            }
        }
    }
}
