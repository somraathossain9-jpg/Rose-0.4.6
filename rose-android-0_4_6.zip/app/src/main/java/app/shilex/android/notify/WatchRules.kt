package app.shilex.android.notify

/**
 * When "watch my messages" speaks up, biased to silence: only a person's message or missed
 * call, or a link from an unknown number; the same person again after [SAME_PERSON_MS] (0: at once),
 * not twice within [GAP_MS], never on a silent phone or while the user is already talking to
 * ROSE. 0.4.1: it says who, where and what they wrote (codes stay hidden).
 * Pure, so it is unit-tested.
 */
class WatchRules {
    private val lastByPerson = mutableMapOf<String, Long>()
    private var lastSpoke = NEVER

    /** What to say about [n] at [now], or null to stay quiet. */
    fun decide(n: Seen, now: Long, phoneSilent: Boolean, inConversation: Boolean): String? {
        val item = Triage.classify(n)
        if (item.kind != Triage.Kind.Needs && item.kind != Triage.Kind.Suspicious) return null
        if (phoneSilent || inConversation) return null
        val who = n.title.ifBlank { n.app }.trim()
        val key = "${n.packageName}|$who"
        if (now - (lastByPerson[key] ?: NEVER) < SAME_PERSON_MS) return null
        if (now - lastSpoke < GAP_MS) return null
        lastByPerson[key] = now
        lastSpoke = now
        return when (item.kind) {
            Triage.Kind.Suspicious -> "Careful: a link from an unknown number on ${n.app}. Don't open it."
            else -> if (n.category == "missed_call" || n.text.contains("missed call", ignoreCase = true)) {
                "Missed call from $who."
            } else {
                // 0.4.1: the owner wants to hear who wrote and what, at once.
                val words = n.text.replace(Regex("\\s+"), " ").trim().take(MAX_WORDS)
                if (words.isEmpty()) "$who sent a message on ${n.app}." else "$who wrote on ${n.app}: $words"
            }
        }
    }

    companion object {
        // 0.4.1: every new message is announced at once (was: 10 min per person, 45 s overall).
        const val SAME_PERSON_MS = 0L
        const val GAP_MS = 2_000L
        private const val MAX_WORDS = 200
        private const val NEVER = Long.MIN_VALUE / 2 // far enough back that any gap has passed, without overflow
    }
}
