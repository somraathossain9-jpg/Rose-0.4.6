package app.shilex.android.tools

import app.shilex.android.Branding
import app.shilex.android.Diag
import app.shilex.android.code.CodeStore
import app.shilex.android.code.PublicFiles
import app.shilex.android.data.KeyVault
import app.shilex.android.data.Settings
import app.shilex.android.memory.MemoryStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Base64
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * The separate "brain": a bigger Gemini model (Settings, "Brain model") for coding, long plans, and writing prompts
 * for pictures and videos, plus a picture model. It sees the owner's saved notes and the code workspace, so it
 * remembers. It uses the owner's own Gemini key. It cannot make videos: it writes the prompt for a video tool.
 */
object BrainTools {
    fun all(): List<PhoneTool> = listOf(Ask, Image)

    private val JSON = "application/json".toMediaType()

    private fun call(http: OkHttpClient, key: String, model: String, body: JSONObject): JSONObject {
        val client = http.newBuilder().readTimeout(150, TimeUnit.SECONDS).callTimeout(170, TimeUnit.SECONDS).pingInterval(0, TimeUnit.SECONDS).build()
        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .header("x-goog-api-key", key)
            .post(body.toString().toRequestBody(JSON))
            .build()
        client.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                Diag.w("brain: Gemini ${response.code} for $model")
                throw IOException("Gemini ${response.code}")
            }
            return JSONObject(text)
        }
    }

    private fun parts(response: JSONObject): JSONArray? =
        response.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")

    /** Removes a wrapping ```code fence``` so saved files hold only the code. */
    internal fun stripFence(text: String): String {
        val t = text.trim()
        if (!t.startsWith("```")) return t
        val body = t.substringAfter('\n', "")
        return body.removeSuffix("```").trimEnd()
    }

    private object Ask : PhoneTool {
        override val name = "brain_ask"

        override fun declaration() = Schema.function(
            name,
            "Asks the bigger \"brain\" model for hard work: writing or fixing code, long plans, or prompts for an image or video " +
                "generator. It sees the owner's saved notes and any workspace files you list. With save_as, the full answer " +
                "is stored in the code workspace (use that for code; then you only say what it did).",
            Schema.string("task", "What to do, with every detail needed.", required = true),
            Schema.string("kind", "code, plan, prompt (for image or video tools) or general.", choices = listOf("code", "plan", "prompt", "general")),
            Schema.strings("files", "Workspace file paths the brain should read first (up to 12)."),
            Schema.string("save_as", "Workspace path to save the whole answer to (code kind: only the file's code is saved)."),
        )

        override suspend fun run(args: JSONObject, host: ToolHost): JSONObject {
            val context = host.context
            val key = KeyVault(context).read(KeyVault.GEMINI_KEY) ?: return Results.failed("no_key", "There is no Gemini key on this phone.")
            val kind = args.text("kind").ifEmpty { "general" }
            val task = args.text("task").ifEmpty { return Results.failed("empty", "Say what the brain should do.") }
            val store = CodeStore(context)
            val saveAs = args.text("save_as")

            val notes = MemoryStore(context).notes().takeLast(40).joinToString("; ") { it.text }.take(3_000)
            val fileBlock = StringBuilder()
            val wanted = args.optJSONArray("files")
            var budget = 60_000
            for (i in 0 until minOf(wanted?.length() ?: 0, 12)) {
                val path = wanted!!.optString(i)
                val text = store.read(path) ?: continue
                val piece = text.take(budget.coerceAtLeast(0))
                if (piece.isEmpty()) break
                fileBlock.append("\n=== FILE $path ===\n").append(piece).append('\n')
                budget -= piece.length
            }
            val role = when (kind) {
                "code" -> "You are a careful senior Android engineer (Kotlin, Jetpack Compose, Gradle, GitHub Actions). Write complete, compilable code. " +
                    "Say what you assumed. Never add code that sends messages, calls, pays or installs without the owner's own tap."
                "plan" -> "You are a clear planner. Give short numbered steps and the risks."
                "prompt" -> "You write excellent prompts for image and video generators: subject, style, camera, light, motion, mood, length. Write the prompt in English, ready to paste."
                else -> "You are a helpful, honest expert."
            }
            val system = "You are the thinking brain of ${Branding.ASSISTANT_NAME}, the phone assistant of ${Branding.OWNER}. $role " +
                (if (notes.isNotEmpty()) "What the owner told Rose to remember: $notes. " else "") +
                (if (saveAs.isNotEmpty() && kind == "code") "Reply with ONLY the complete content of the file, no explanation, no code fence. " else "")
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", task + fileBlock)))))
                .put("generationConfig", JSONObject().put("maxOutputTokens", 16_384).put("temperature", 0.4))
            return withContext(Dispatchers.IO) {
                try {
                    val reply = call(host.http, key, Settings(context).brainModel, body)
                    val p = parts(reply)
                    val answer = (0 until (p?.length() ?: 0)).joinToString("") { p!!.optJSONObject(it)?.optString("text").orEmpty() }.trim()
                    if (answer.isEmpty()) return@withContext Results.failed("empty_answer", "The brain gave no answer. Offer to try again.")
                    if (saveAs.isNotEmpty()) {
                        val content = if (kind == "code") stripFence(answer) else answer
                        val problem = store.write(saveAs, content)
                        if (problem != null) return@withContext Results.failed("not_saved", problem)
                        Results.done("The brain wrote $saveAs (${content.length} characters) in the workspace.").put("preview", content.take(500))
                    } else {
                        Results.done(answer.take(6_000)).put("truncated", answer.length > 6_000)
                    }
                } catch (e: IOException) {
                    Results.failed("brain_failed", "The brain model did not answer (${e.message}). Check the Brain model name in Settings, then offer to try again.")
                } catch (e: org.json.JSONException) {
                    Results.failed("brain_failed", "The brain model sent something unexpected.")
                }
            }
        }
    }

    private object Image : PhoneTool {
        override val name = "brain_image"

        override fun declaration() = Schema.function(
            name,
            "Makes a picture from a description and saves it in the phone's Pictures/Rose folder. Describe it in English in detail. " +
                "This cannot make videos.",
            Schema.string("prompt", "What the picture shows.", required = true),
        )

        override suspend fun run(args: JSONObject, host: ToolHost): JSONObject {
            val context = host.context
            val key = KeyVault(context).read(KeyVault.GEMINI_KEY) ?: return Results.failed("no_key", "There is no Gemini key on this phone.")
            val prompt = args.text("prompt").ifEmpty { return Results.failed("empty", "Say what the picture should show.") }
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("TEXT").put("IMAGE")))
            return withContext(Dispatchers.IO) {
                try {
                    val p = parts(call(host.http, key, Settings(context).imageModel, body))
                    for (i in 0 until (p?.length() ?: 0)) {
                        val inline = p!!.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
                        val bytes = Base64.getMimeDecoder().decode(inline.optString("data"))
                        val mime = inline.optString("mimeType").ifEmpty { "image/png" }
                        val ext = if (mime.contains("jpeg")) "jpg" else "png"
                        val name = "rose-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + "." + ext
                        return@withContext if (PublicFiles.savePicture(context, name, mime, bytes)) {
                            Results.done("Saved the picture $name in the Pictures/Rose folder.")
                        } else {
                            Results.failed("not_saved", "The phone would not save the picture.")
                        }
                    }
                    Results.failed("no_picture", "The model gave no picture (it may have refused the idea). Offer a different description.")
                } catch (e: IOException) {
                    Results.failed("image_failed", "The picture model did not answer (${e.message}). Check the Picture model name in Settings.")
                } catch (e: org.json.JSONException) {
                    Results.failed("image_failed", "The picture model sent something unexpected.")
                } catch (e: IllegalArgumentException) {
                    Results.failed("image_failed", "The picture came back damaged.")
                }
            }
        }
    }
}
