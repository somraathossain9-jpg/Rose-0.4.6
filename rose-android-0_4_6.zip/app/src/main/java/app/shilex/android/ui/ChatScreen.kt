package app.shilex.android.ui

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.shilex.android.Branding
import app.shilex.android.chat.Attachment
import app.shilex.android.chat.ChatEngine
import app.shilex.android.chat.ChatVoice
import app.shilex.android.data.Settings
import app.shilex.android.tools.Approval
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull
import app.shilex.android.control.ControlService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Text chat with ROSE: type, and send pictures, screenshots and short videos. */
@Composable
fun ChatScreen() {
    val context = LocalContext.current
    val chat = remember { ChatEngine.get(context) }
    val lines by chat.lines.collectAsStateWithLifecycle()
    val busy by chat.busy.collectAsStateWithLifecycle()
    val waiting by chat.waiting.collectAsStateWithLifecycle()
    val draft by chat.draft.collectAsStateWithLifecycle()
    var text by remember { mutableStateOf("") }
    var note by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val list = rememberLazyListState()
    val settings = remember { Settings(context) }
    var speakerOn by remember { mutableStateOf(settings.chatSpeaker) }
    // The Allow button for pushes and installs asked by Rose from this chat (only a finger can press it).
    var allowAsk by remember { mutableStateOf<Pair<String, CompletableDeferred<Boolean>>?>(null) }

    DisposableEffect(Unit) {
        val asker: suspend (String) -> Boolean = { what ->
            val answer = CompletableDeferred<Boolean>()
            allowAsk = what to answer
            try {
                withTimeoutOrNull(90_000L) { answer.await() } ?: false
            } finally {
                allowAsk = null
            }
        }
        Approval.screenAsker = asker
        onDispose {
            if (Approval.screenAsker === asker) Approval.screenAsker = null
            ChatVoice.stop()
        }
    }

    // Speaker on: every new answer from Rose is read aloud.
    var spokenUpTo by remember { mutableStateOf(lines.size) }
    LaunchedEffect(lines.size, speakerOn) {
        val fresh = lines.drop(spokenUpTo)
        spokenUpTo = lines.size
        if (speakerOn) fresh.lastOrNull { !it.fromUser && !it.tool }?.let { ChatVoice.speak(context, it.text) }
    }

    // Talk instead of typing: the phone's own speech recogniser fills the message box.
    val dictate = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val said = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (said.isNotBlank()) text = if (text.isBlank()) said else "$text $said"
        }
    }

    LaunchedEffect(draft) {
        if (draft.isNotEmpty()) {
            text = draft
            chat.setDraft("")
        }
    }
    LaunchedEffect(lines.size) { if (lines.isNotEmpty()) list.animateScrollToItem(lines.lastIndex) }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        scope.launch {
            uris.forEach { uri ->
                val (attachment, problem) = withContext(Dispatchers.IO) { ChatEngine.load(context, uri) }
                if (attachment != null) chat.addWaiting(attachment) else note = problem
            }
        }
    }

    allowAsk?.let { (what, answer) ->
        AlertDialog(
            onDismissRequest = { answer.complete(false) },
            title = { Text("${Branding.ASSISTANT_NAME} wants to") },
            text = { Text(what) },
            confirmButton = { TextButton(onClick = { answer.complete(true) }) { Text("Allow") } },
            dismissButton = { TextButton(onClick = { answer.complete(false) }) { Text("Cancel") } },
        )
    }

    Column(Modifier.fillMaxSize().imePadding().padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Chat with ${Branding.ASSISTANT_NAME}", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            TextButton(onClick = {
                speakerOn = !speakerOn
                settings.chatSpeaker = speakerOn
                if (!speakerOn) ChatVoice.stop()
            }) { Text(if (speakerOn) "Speaker: On" else "Speaker: Off") }
            TextButton(onClick = { ChatVoice.stop(); chat.clear() }) { Text("Clear") }
        }
        if (lines.isEmpty()) {
            Text(
                "Write or talk (Mic) to ${Branding.ASSISTANT_NAME}, or send a picture, a screenshot or a short video. " +
                    "Turn Speaker on to hear her answers; Copy copies a message. " +
                    "Ask her to update the app (code, GitHub build, install) right here. Phone actions (calls, messages, apps) work by voice on Home.",
                style = MaterialTheme.typography.bodyMedium,
                color = Muted,
                modifier = Modifier.padding(top = 8.dp),
            )
        }
        LazyColumn(Modifier.fillMaxWidth().weight(1f).padding(top = 8.dp), state = list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(lines, key = { it.id }) { line ->
                Column(Modifier.fillMaxWidth(), horizontalAlignment = if (line.fromUser) Alignment.End else Alignment.Start) {
                    if (line.tool) {
                        Text(line.text, style = MaterialTheme.typography.labelSmall, color = Muted)
                    } else {
                        SelectionContainer {
                            Text(
                                line.text,
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (line.fromUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier
                                    .background(if (line.fromUser) Accent else Surface, RoundedCornerShape(16.dp))
                                    .padding(horizontal = 14.dp, vertical = 9.dp),
                            )
                        }
                        Row {
                            TextButton(onClick = { copyText(context, line.text) }) { Text("Copy", style = MaterialTheme.typography.labelSmall) }
                            if (!line.fromUser) {
                                TextButton(onClick = { ChatVoice.speak(context, line.text) }) { Text("Listen", style = MaterialTheme.typography.labelSmall) }
                                TextButton(onClick = { ChatVoice.stop() }) { Text("Stop", style = MaterialTheme.typography.labelSmall) }
                            }
                        }
                    }
                }
            }
        }
        if (busy) Text("${Branding.ASSISTANT_NAME} is working…", style = MaterialTheme.typography.bodySmall, color = Muted)
        note?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = Warning, modifier = Modifier.padding(top = 4.dp)) }
        waiting.forEach { a: Attachment ->
            Text(
                "${a.label}  (tap to remove)",
                style = MaterialTheme.typography.bodySmall,
                color = Muted,
                modifier = Modifier.clickable { chat.removeWaiting(a) }.padding(vertical = 3.dp),
            )
        }
        Row {
            TextButton(onClick = {
                note = null
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                    .putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to ${Branding.ASSISTANT_NAME}")
                try {
                    dictate.launch(intent)
                } catch (_: ActivityNotFoundException) {
                    note = "This phone has no speech recogniser. Use the keyboard's mic button instead."
                }
            }) { Text("Mic") }
            TextButton(onClick = { note = null; pick.launch("image/*") }) { Text("Photo") }
            TextButton(onClick = { note = null; pick.launch("video/*") }) { Text("Video") }
            TextButton(onClick = {
                val service = ControlService.instance
                if (service == null) {
                    note = "Screenshots need Phone control (turn it on in Settings). Or share a screenshot to ${Branding.ASSISTANT_NAME} from your gallery."
                } else {
                    note = "Taking a screenshot in 5 seconds: go to the screen you want to share."
                    scope.launch {
                        delay(5_000)
                        val shot = service.screenshot()
                        note = if (shot == null) {
                            "Android would not give the screenshot (protected screen, or Android 10)."
                        } else {
                            chat.addWaiting(Attachment("image/jpeg", ChatEngine.jpeg(shot), "screenshot"))
                            "Screenshot added. Come back here and send."
                        }
                    }
                }
            }) { Text("Screenshot") }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                placeholder = { Text("Message") },
                modifier = Modifier.weight(1f),
                maxLines = 4,
            )
            Button(
                enabled = !busy && (text.isNotBlank() || waiting.isNotEmpty()),
                onClick = {
                    val message = text
                    text = ""
                    note = null
                    chat.submit(message)
                },
                modifier = Modifier.padding(start = 8.dp),
            ) { Text("Send") }
        }
    }
}

/** Puts [text] on the phone's clipboard so it can be pasted anywhere. */
private fun copyText(context: Context, text: String) {
    val clipboard = context.getSystemService(ClipboardManager::class.java)
    clipboard.setPrimaryClip(ClipData.newPlainText("ROSE", text))
    Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
}
