package app.shilex.android.code

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.Base64
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

/** What went wrong talking to GitHub, in words the model can say. */
class GitHubException(message: String) : Exception(message)

/** Pure helpers, unit-tested. */
object GitHubRules {
    private val REPO = Regex("^[A-Za-z0-9_.-]{1,100}/[A-Za-z0-9_.-]{1,100}$")
    private val BRANCH = Regex("^[A-Za-z0-9._/-]{1,100}$")
    private val WORKFLOW = Regex("^[A-Za-z0-9_.-]{1,80}\\.ya?ml$")
    private val BINARY = setOf(
        "png", "jpg", "jpeg", "webp", "gif", "ico", "jar", "so", "zip", "apk", "aab", "onnx", "ttf", "otf", "mp3", "mp4", "ogg", "wav", "bin", "dex",
    )

    fun validRepo(repo: String) = REPO.matches(repo)

    /** Rose never pushes to the main line: only to a work branch. */
    fun validWorkBranch(branch: String) =
        BRANCH.matches(branch) && !branch.startsWith("/") && !branch.contains("..") && !branch.endsWith("/") &&
            branch.lowercase() !in setOf("main", "master", "develop", "release", "production")

    private val SECRET = listOf(
        Regex("gh[pousr]_[A-Za-z0-9]{20,}"),
        Regex("github_pat_[A-Za-z0-9_]{20,}"),
        Regex("AIza[0-9A-Za-z_-]{30,}"),
        Regex("-----BEGIN [A-Z ]*PRIVATE KEY-----"),
        Regex("(?i)(otp|pin|password|passwd|bkash|nagad|upay)\\s*[:=]\\s*[\"'][^\"'\\s]{4,}[\"']"),
    )

    /** True when a file looks like it holds a key, token, PIN, OTP or payment password: it is never written or pushed. */
    fun looksSecret(text: String) = SECRET.any { it.containsMatchIn(text) }

    fun validWorkflow(name: String) = WORKFLOW.matches(name)

    fun isText(path: String) = path.substringAfterLast('.', "").lowercase() !in BINARY

    /** Git's own id for a file's content, to push only what changed. */
    fun blobSha(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-1")
        digest.update("blob ${bytes.size}\u0000".toByteArray())
        digest.update(bytes)
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    fun modeFor(path: String) = if (path == "gradlew" || path.endsWith(".sh")) "100755" else "100644"

    /** The useful part of a long build log: error lines first, then the tail. */
    fun digestLog(log: String, maxChars: Int = 4_000): String {
        val lines = log.lines().map { it.replace(Regex("^\\d{4}-\\d\\d-\\d\\dT[\\d:.]+Z\\s*"), "").trim() }.filter { it.isNotEmpty() }
        val interesting = Regex("(error|e: |FAILED|What went wrong|Exception|Unresolved reference|Could not)", RegexOption.IGNORE_CASE)
        val errors = lines.filter { interesting.containsMatchIn(it) }.distinct().take(40).map { it.take(240) }
        val tail = lines.takeLast(12).map { it.take(240) }
        return ("Errors:\n" + errors.joinToString("\n") + "\n\nEnd of log:\n" + tail.joinToString("\n")).take(maxChars)
    }
}

/** A small GitHub REST client for one repo, with the owner's own token. */
class GitHub(http: OkHttpClient, private val token: String, val repo: String) {
    private val client = http.newBuilder().readTimeout(90, TimeUnit.SECONDS).callTimeout(180, TimeUnit.SECONDS).pingInterval(0, TimeUnit.SECONDS).build()
    private val json = "application/json".toMediaType()

    class Reply(val code: Int, val body: String) {
        val ok get() = code in 200..299
        fun obj() = JSONObject(body)
        fun array() = JSONArray(body)
    }

    private fun request(path: String, method: String, body: JSONObject?): Request {
        val payload = body?.toString()?.toRequestBody(json) ?: if (method == "GET" || method == "HEAD") null else "".toRequestBody(null)
        return Request.Builder()
            .url("https://api.github.com/repos/$repo$path")
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/vnd.github+json")
            .header("X-GitHub-Api-Version", "2022-11-28")
            .method(method, payload)
            .build()
    }

    fun call(method: String, path: String, body: JSONObject? = null): Reply =
        client.newCall(request(path, method, body)).execute().use { Reply(it.code, it.body?.string().orEmpty()) }

    /** Streams a download (zip of the repo, a build artifact) to [dest]; returns the HTTP code. */
    fun download(path: String, dest: File, maxBytes: Long = 200L * 1024 * 1024): Int =
        client.newCall(request(path, "GET", null)).execute().use { response ->
            if (!response.isSuccessful) return response.code
            var total = 0L
            response.body?.byteStream()?.use { input ->
                dest.outputStream().use { out ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        total += n
                        if (total > maxBytes) throw GitHubException("The download is too big.")
                        out.write(buffer, 0, n)
                    }
                }
            }
            response.code
        }

    private fun must(reply: Reply, what: String): Reply {
        if (reply.ok) return reply
        val detail = runCatching { reply.obj().optString("message") }.getOrDefault("")
        throw GitHubException(
            when (reply.code) {
                401 -> "GitHub refused the token (expired or wrong). The owner must make a new one in ROSE's settings."
                403 -> "GitHub says this token is not allowed to $what. $detail".trim()
                404 -> "GitHub could not find it for $what (wrong repo name, or the token cannot see this repo). $detail".trim()
                else -> "GitHub failed at $what (${reply.code}). $detail".trim()
            },
        )
    }

    fun defaultBranch(): String = must(call("GET", ""), "read the repo").obj().getString("default_branch")

    /** What a push would change, worked out without changing anything. */
    class Plan(val branch: String, val baseSha: String, val baseTree: String, val branchExists: Boolean, val defaultBranch: String, val changed: List<String>, val modes: Map<String, String>)

    fun plan(files: Map<String, ByteArray>, branch: String): Plan {
        val default = defaultBranch()
        if (!GitHubRules.validWorkBranch(branch) || branch == default) {
            throw GitHubException("Rose never pushes to \"$branch\". Use a work branch such as rose-work.")
        }
        val ref = call("GET", "/git/ref/heads/$branch")
        val exists = ref.code != 404
        val baseSha = if (exists) {
            must(ref, "read the branch").obj().getJSONObject("object").getString("sha")
        } else {
            must(call("GET", "/git/ref/heads/$default"), "read $default").obj().getJSONObject("object").getString("sha")
        }
        val baseTree = must(call("GET", "/git/commits/$baseSha"), "read the commit").obj().getJSONObject("tree").getString("sha")
        val tree = must(call("GET", "/git/trees/$baseTree?recursive=1"), "read the file list").obj().getJSONArray("tree")
        val existing = HashMap<String, Pair<String, String>>()
        for (i in 0 until tree.length()) {
            val t = tree.getJSONObject(i)
            if (t.optString("type") == "blob") existing[t.getString("path")] = t.getString("sha") to t.getString("mode")
        }
        val changed = ArrayList<String>()
        val modes = HashMap<String, String>()
        for ((path, bytes) in files) {
            val old = existing[path]
            if (old != null && old.first == GitHubRules.blobSha(bytes)) continue
            changed += path
            modes[path] = old?.second ?: GitHubRules.modeFor(path)
        }
        return Plan(branch, baseSha, baseTree, exists, default, changed.sorted(), modes)
    }

    /** Makes the commit on the work branch (creating it from the default branch if needed). Returns the commit id. */
    fun apply(plan: Plan, files: Map<String, ByteArray>, message: String): String {
        if (plan.changed.isEmpty()) return plan.baseSha
        if (!plan.branchExists) {
            must(
                call("POST", "/git/refs", JSONObject().put("ref", "refs/heads/${plan.branch}").put("sha", plan.baseSha)),
                "create the branch",
            )
        }
        val entries = JSONArray()
        for (path in plan.changed) {
            val bytes = files.getValue(path)
            val blob = must(
                call("POST", "/git/blobs", JSONObject().put("content", Base64.getEncoder().encodeToString(bytes)).put("encoding", "base64")),
                "upload $path",
            ).obj().getString("sha")
            entries.put(JSONObject().put("path", path).put("mode", plan.modes.getValue(path)).put("type", "blob").put("sha", blob))
        }
        val tree = must(
            call("POST", "/git/trees", JSONObject().put("base_tree", plan.baseTree).put("tree", entries)),
            "write the file list",
        ).obj().getString("sha")
        val commit = must(
            call("POST", "/git/commits", JSONObject().put("message", message).put("tree", tree).put("parents", JSONArray().put(plan.baseSha))),
            "make the commit",
        ).obj().getString("sha")
        must(call("PATCH", "/git/refs/heads/${plan.branch}", JSONObject().put("sha", commit)), "move the branch")
        return commit
    }

    fun runWorkflow(workflow: String, branch: String) {
        must(call("POST", "/actions/workflows/$workflow/dispatches", JSONObject().put("ref", branch)), "start the build")
    }

    class Run(val id: Long, val status: String, val conclusion: String, val sha: String, val url: String)

    fun latestRun(branch: String, successOnly: Boolean = false): Run? {
        val query = "/actions/runs?branch=$branch&per_page=1" + if (successOnly) "&status=success" else ""
        val runs = must(call("GET", query), "read the builds").obj().getJSONArray("workflow_runs")
        if (runs.length() == 0) return null
        val r = runs.getJSONObject(0)
        return Run(r.getLong("id"), r.optString("status"), r.optString("conclusion"), r.optString("head_sha").take(7), r.optString("html_url"))
    }

    /** The newest run of the build for one commit (a push starts it a few seconds later), or null if none yet. */
    fun runForCommit(branch: String, commit: String): Run? {
        val runs = must(call("GET", "/actions/runs?branch=$branch&per_page=10"), "read the builds").obj().getJSONArray("workflow_runs")
        for (i in 0 until runs.length()) {
            val r = runs.getJSONObject(i)
            if (r.optString("head_sha").startsWith(commit.take(7))) {
                return Run(r.getLong("id"), r.optString("status"), r.optString("conclusion"), r.optString("head_sha").take(7), r.optString("html_url"))
            }
        }
        return null
    }

    /** The failed step's name and the useful part of its log. */
    fun failureDigest(runId: Long): String {
        val jobs = must(call("GET", "/actions/runs/$runId/jobs"), "read the build jobs").obj().getJSONArray("jobs")
        for (i in 0 until jobs.length()) {
            val job = jobs.getJSONObject(i)
            if (job.optString("conclusion") != "failure") continue
            val steps = job.optJSONArray("steps")
            val failedStep = (0 until (steps?.length() ?: 0)).map { steps!!.getJSONObject(it) }
                .firstOrNull { it.optString("conclusion") == "failure" }?.optString("name").orEmpty()
            val log = call("GET", "/actions/jobs/${job.getLong("id")}/logs")
            val digest = if (log.ok) GitHubRules.digestLog(log.body) else "The log could not be read (${log.code})."
            return "Failed step: $failedStep\n$digest"
        }
        return "No failed job found in this run."
    }

    /** Downloads the newest built APK from a run's artifacts into [dest]. Returns false if there is none. */
    fun downloadApk(runId: Long, dest: File): Boolean {
        val artifacts = must(call("GET", "/actions/runs/$runId/artifacts"), "read the build files").obj().getJSONArray("artifacts")
        // 0.4.6: the plain "rose-apk" is signed with the app's fixed key; the optional release one uses another key.
        var id = -1L
        var fallback = -1L
        for (i in 0 until artifacts.length()) {
            val a = artifacts.getJSONObject(i)
            if (a.optBoolean("expired")) continue
            val name = a.optString("name")
            if (name == "rose-apk" && id < 0) id = a.getLong("id")
            if (name.startsWith("rose-apk") && fallback < 0) fallback = a.getLong("id")
        }
        if (id < 0) id = fallback
        if (id < 0) return false
        val zip = File(dest.parentFile, "artifact.zip")
        val code = download("/actions/artifacts/$id/zip", zip)
        if (code !in 200..299) throw GitHubException("GitHub would not give the build file ($code).")
        var found = false
        ZipInputStream(zip.inputStream()).use { input ->
            while (true) {
                val entry = input.nextEntry ?: break
                if (!entry.isDirectory && entry.name.endsWith(".apk")) {
                    dest.outputStream().use { input.copyTo(it) }
                    found = true
                    break
                }
            }
        }
        zip.delete()
        return found
    }

    /** Copies the repo's text files into [store]; returns how many. */
    fun pull(ref: String, store: CodeStore, temp: File): Int {
        val zip = File(temp, "repo.zip")
        val code = download("/zipball/$ref", zip)
        if (code !in 200..299) throw GitHubException("GitHub would not give the code ($code).")
        var count = 0
        ZipInputStream(zip.inputStream()).use { input ->
            while (true) {
                val entry = input.nextEntry ?: break
                if (entry.isDirectory) continue
                val path = entry.name.substringAfter('/', "")
                if (path.isEmpty() || !GitHubRules.isText(path) || CodePaths.clean(path) == null) continue
                val bytes = input.readBytes()
                if (bytes.size > CodePaths.MAX_FILE) continue
                if (store.writeBytes(path, bytes) == null) count++
            }
        }
        zip.delete()
        return count
    }

    fun readFile(path: String, ref: String): String? {
        val reply = call("GET", "/contents/$path?ref=$ref")
        if (reply.code == 404) return null
        val obj = must(reply, "read $path").obj()
        if (obj.optString("encoding") != "base64") return null
        return String(Base64.getMimeDecoder().decode(obj.getString("content")), Charsets.UTF_8)
    }
}
