package app.shilex.android.chat

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import app.shilex.android.Diag
import app.shilex.android.assistant.Instructions
import app.shilex.android.task.Capabilities
import app.shilex.android.tools.BrainTools
import app.shilex.android.tools.CodeTools
import app.shilex.android.tools.GitHubTools
import app.shilex.android.tools.PhoneTool
import app.shilex.android.tools.Results
import app.shilex.android.tools.SelfTools
import app.shilex.android.tools.ToolHost
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import app.shilex.android.data.KeyVault
import app.shilex.android.data.Settings
import app.shilex.android.memory.MemoryStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.Base64
import java.util.concurrent.TimeUnit

/** A picture or short video the owner gives ROSE in the text chat. */
class Attachment(val mime: String, val bytes: ByteArray, val label: String)

/** [tool] lines are small status notes ("Change code: done"), not Rose's words. */
data class ChatLine(val id: Long, val fromUser: Boolean, val text: String, val tool: Boolean = false)

/**
 * Text chat with ROSE: text, pictures, screenshots and short videos go to Gemini (generateContent, the owner's own key).
 * 0.4.6: the chat can also use the code and GitHub tools, so Rose can change her own code here, push it, wait for the build
 * and install the update (each push and install needs the owner's Allow button). Phone actions (calls, messages, apps) still
 * work by voice. The conversation lives in memory until cleared.
 */
class ChatEngine private constructor(private val app: Application) {
    private val _lines = MutableStateFlow<List<ChatLine>>(emptyList())
    val lines: StateFlow<List<ChatLine>> = _lines.asStateFlow()
    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()
    private val _waiting = MutableStateFlow<List<Attachment>>(emptyList())

    /** Pictures and videos picked or shared in, waiting for the next message. */
    val waiting: StateFlow<List<Attachment>> = _waiting.asStateFlow()
    private val _draft = MutableStateFlow("")

    /** Text shared into ROSE from another app. */
    val draft: StateFlow<String> = _draft.asStateFlow()
    private val _openRequest = MutableStateFlow(false)
    val openRequest: StateFlow<Boolean> = _openRequest.asStateFlow()

    private val history = JSONArray()
    private var nextId = 1L
    private val http = OkHttpClient.Builder().readTimeout(120, TimeUnit.SECONDS).callTimeout(150, TimeUnit.SECONDS).build()

    fun requestOpen() { _openRequest.value = true }
    fun openHandled() { _openRequest.value = false }
    fun setDraft(text: String) { _draft.value = text }
    fun addWaiting(a: Attachment) = _waiting.update { (it + a).takeLast(MAX_WAITING) }
    fun removeWaiting(a: Attachment) = _waiting.update { it - a }

    fun clear() {
        while (history.length() > 0) history.remove(0)
        _lines.value = emptyList()
        _waiting.value = emptyList()
    }

    private fun add(fromUser: Boolean, text: String, tool: Boolean = false) =
        _lines.update { it + ChatLine(nextId++, fromUser, text, tool) }

    /** The tools the chat may use: the owner's code workspace, GitHub, the brain and the self report. Same capability list as voice. */
    private val chatTools: Map<String, PhoneTool> =
        (CodeTools.all() + GitHubTools.all() + BrainTools.all() + SelfTools.all())
            .filter { Capabilities.of(it.name) != null }
            .associateBy { it.name }

    private val host = object : ToolHost {
        override val context: Context get() = app
        override val http: OkHttpClient get() = this@ChatEngine.http
        override fun requestPermission(permission: String) = Unit
        override fun hasPermission(permission: String) =
            ContextCompat.checkSelfPermission(app, permission) == PackageManager.PERMISSION_GRANTED

        // The chat is on screen, so the installer or a settings page can open at once.
        override fun openApp(intent: Intent, label: String, done: String, then: (suspend () -> String?)?): JSONObject =
            startNow(intent, label, done)

        override fun endSessionSoon() = Unit

        override fun startNow(intent: Intent, label: String, done: String): JSONObject = try {
            app.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Results.done(done)
        } catch (e: Exception) {
            Diag.w("chat: could not open $label (${e.javaClass.simpleName})")
            Results.failed("no_app", "The phone would not open $label.")
        }
    }

    /** Runs one tool call from the model and returns what it should read. Never throws. */
    private suspend fun runTool(name: String, args: JSONObject): JSONObject {
        val tool = chatTools[name] ?: return Results.failed("unknown_tool", "There is no tool called $name here.")
        return try {
            withTimeout(TOOL_TIMEOUT_MS) { tool.run(args, host) }
        } catch (_: TimeoutCancellationException) {
            Results.failed("timeout", "That took too long. Say so and offer to try again.")
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            Diag.w("chat: tool $name crashed: ${e.javaClass.simpleName}")
            Results.failed("error", "Something went wrong on the phone. Say so plainly.")
        }
    }

    // The chat keeps working (a build wait, an update) when the owner switches to another tab.
    private val scope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + Dispatchers.Main)

    fun submit(text: String) {
        scope.launch { send(text) }
    }

    suspend fun send(text: String) {
        val attachments = _waiting.value
        if (text.isBlank() && attachments.isEmpty()) return
        if (_busy.value) return
        val key = KeyVault(app).read(KeyVault.GEMINI_KEY)
        if (key == null) {
            add(false, "There is no Gemini key on this phone.")
            return
        }
        _busy.value = true
        _waiting.value = emptyList()
        add(true, (attachments.map { "[${it.label}]" } + text.trim()).filter { it.isNotEmpty() }.joinToString(" "))
        try {
            val settings = Settings(app)
            val parts = JSONArray()
            attachments.forEach {
                parts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", it.mime).put("data", Base64.getEncoder().encodeToString(it.bytes))))
            }
            parts.put(JSONObject().put("text", text.trim().ifEmpty { "Look at this and tell me what you see." }))
            val system = Instructions.chat(
                settings.replyLanguage,
                java.time.ZonedDateTime.now(),
                settings.friendly,
                MemoryStore(app).notes().takeLast(40).joinToString("; ") { it.text }.takeLast(2_500),
                settings.englishFun,
            )
            val contents = JSONArray()
            for (i in 0 until history.length()) contents.put(history.get(i))
            contents.put(JSONObject().put("role", "user").put("parts", parts))
            val declarations = JSONArray().also { list -> chatTools.values.forEach { list.put(it.declaration()) } }
            var answer = ""
            for (step in 0 until MAX_STEPS) {
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                    .put("contents", contents)
                    .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", declarations)))
                    .put("generationConfig", JSONObject().put("maxOutputTokens", 8192))
                val content = withContext(Dispatchers.IO) { ask(key, settings.chatModel, body) }
                val replyParts = content.optJSONArray("parts") ?: JSONArray()
                val calls = (0 until replyParts.length()).mapNotNull { replyParts.optJSONObject(it)?.optJSONObject("functionCall") }
                if (calls.isEmpty()) {
                    answer = (0 until replyParts.length()).joinToString("") { replyParts.optJSONObject(it)?.optString("text").orEmpty() }.trim()
                    break
                }
                // Keep the model's own turn exactly as it came (some models need their hidden notes sent back).
                contents.put(JSONObject().put("role", "model").put("parts", replyParts))
                val results = JSONArray()
                for (call in calls) {
                    val name = call.optString("name")
                    val result = runTool(name, call.optJSONObject("args") ?: JSONObject())
                    val title = Capabilities.of(name)?.title ?: name
                    add(false, "$title: ${result.optString("status").ifEmpty { "done" }}", tool = true)
                    results.put(JSONObject().put("functionResponse", JSONObject().put("name", name).put("response", result)))
                }
                contents.put(JSONObject().put("role", "user").put("parts", results))
                if (step == MAX_STEPS - 1) answer = "(I did many steps and stopped here. Tell me to carry on if you want.)"
            }
            if (answer.isEmpty()) answer = "(Gemini gave no answer. Try again.)"
            // Keep only a note of the pictures in the history, so they are not sent again every turn.
            val kept = (attachments.map { "[sent ${it.label}]" } + text.trim()).filter { it.isNotEmpty() }.joinToString(" ")
            history.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", kept))))
            history.put(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", answer))))
            while (history.length() > MAX_HISTORY) history.remove(0)
            add(false, answer)
        } catch (e: IOException) {
            Diag.w("chat: failed (${e.javaClass.simpleName})")
            add(false, "(${e.message ?: "The network failed"}. Check the Chat model name in Settings, then try again.)")
        } catch (e: org.json.JSONException) {
            add(false, "(Gemini sent something unexpected. Try again.)")
        } finally {
            _busy.value = false
        }
    }

    private fun ask(key: String, model: String, body: JSONObject): JSONObject {
        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .header("x-goog-api-key", key)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        http.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IOException("Gemini ${response.code}")
            return JSONObject(text).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                ?: throw IOException("Gemini gave no answer")
        }
    }

    companion object {
        private const val MAX_STEPS = 14
        private const val TOOL_TIMEOUT_MS = 200_000L
        private const val MAX_WAITING = 4
        private const val MAX_HISTORY = 30
        const val MAX_IMAGE_SIDE = 1600
        const val MAX_VIDEO = 14_000_000

        @Volatile private var instance: ChatEngine? = null

        fun get(context: Context): ChatEngine = instance ?: synchronized(this) {
            instance ?: ChatEngine(context.applicationContext as Application).also { instance = it }
        }

        /** Reads a picked or shared file. Null attachment plus a reason when it is too big or not a picture or video. */
        fun load(context: Context, uri: Uri): Pair<Attachment?, String?> {
            val resolver = context.contentResolver
            val mime = resolver.getType(uri).orEmpty()
            val name = runCatching {
                resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
            }.getOrNull() ?: "file"
            return try {
                when {
                    mime.startsWith("image/") -> {
                        val raw = resolver.openInputStream(uri)?.use { it.readBytes() } ?: return null to "Could not open that picture."
                        Attachment("image/jpeg", shrink(raw), name) to null
                    }
                    mime.startsWith("video/") -> {
                        val out = ByteArrayOutputStream()
                        resolver.openInputStream(uri)?.use { input ->
                            val buffer = ByteArray(64 * 1024)
                            while (true) {
                                val n = input.read(buffer)
                                if (n < 0) break
                                out.write(buffer, 0, n)
                                if (out.size() > MAX_VIDEO) return null to "That video is over ${MAX_VIDEO / 1_000_000} MB. Trim it to a short clip."
                            }
                        } ?: return null to "Could not open that video."
                        Attachment(mime, out.toByteArray(), name) to null
                    }
                    else -> null to "Only pictures and short videos can be sent."
                }
            } catch (e: IOException) {
                null to "Could not read that file."
            } catch (e: SecurityException) {
                null to "ROSE is not allowed to read that file."
            }
        }

        /** Re-encodes a picture as a JPEG at most [MAX_IMAGE_SIDE] pixels wide or high. */
        fun shrink(raw: ByteArray): ByteArray {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(raw, 0, raw.size, bounds)
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= MAX_IMAGE_SIDE) sample *= 2
            val bitmap = BitmapFactory.decodeByteArray(raw, 0, raw.size, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return raw
            return jpeg(bitmap)
        }

        fun jpeg(bitmap: Bitmap): ByteArray {
            val out = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 85, out)
            return out.toByteArray()
        }
    }
}
