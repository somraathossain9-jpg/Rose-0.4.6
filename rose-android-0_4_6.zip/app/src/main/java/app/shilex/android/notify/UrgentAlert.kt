package app.shilex.android.notify

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import app.shilex.android.Diag
import app.shilex.android.MainActivity
import app.shilex.android.R

/** Tells the owner, loudly, when busy mode decides a message can't wait. Local only. */
object UrgentAlert {
    private const val CHANNEL = "rose_urgent"

    fun show(context: Context, who: String, app: String, summary: String) {
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL, "Urgent messages", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Messages ROSE thinks can't wait while she answers for you"
            },
        )
        if (!canPost(context)) return
        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val text = summary.ifBlank { "Needs you now" }
        val n = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Urgent: $who ($app)")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        runCatching { NotificationManagerCompat.from(context).notify(("urgent|$who").hashCode(), n) }
            .onFailure { Diag.w("urgent: could not notify (${it.javaClass.simpleName})") }
    }

    /**
     * 0.4.6: a quiet note of what came in and what Rose answered, so it is on the screen too when the phone is on silent
     * or the owner missed the spoken line. Never asks for any permission: without the notification permission it is skipped.
     */
    fun report(context: Context, who: String, app: String, theirs: String, reply: String) {
        if (!canPost(context)) return
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(REPORT_CHANNEL, "Auto reply report", NotificationManager.IMPORTANCE_LOW).apply {
                description = "What came in and what ROSE answered for you"
            },
        )
        val open = PendingIntent.getActivity(
            context, 1, Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val body = "$who ($app) লিখেছেন: ${theirs.take(200)}\nআমি উত্তর দিয়েছি: ${reply.take(200)}"
        val n = NotificationCompat.Builder(context, REPORT_CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Auto reply: $who")
            .setContentText(reply.take(80))
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        runCatching { NotificationManagerCompat.from(context).notify(("report|$who").hashCode(), n) }
            .onFailure { Diag.w("report: could not notify (${it.javaClass.simpleName})") }
    }

    private const val REPORT_CHANNEL = "rose_auto_report"

    private fun canPost(context: Context) =
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
}
