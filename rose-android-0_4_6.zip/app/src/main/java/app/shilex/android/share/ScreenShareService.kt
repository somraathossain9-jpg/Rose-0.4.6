package app.shilex.android.share

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import app.shilex.android.Branding
import app.shilex.android.Diag
import app.shilex.android.R
import app.shilex.android.assistant.VoiceSession
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.ByteArrayOutputStream

/**
 * Live screen share (0.4.3): while a conversation runs, a small picture of the screen goes to Gemini about once a
 * second so ROSE can see what the owner sees. Android asks the owner every time, a notification shows while it
 * runs, it stops with the conversation, and protected screens (passwords, banking) arrive black.
 */
class ScreenShareService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    @Volatile private var lastFrame = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = intent?.getParcelableExtra(EXTRA_DATA)
        if (data == null || code == 0) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTE_ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        if (!begin(code, data)) {
            stopSelf()
            return START_NOT_STICKY
        }
        _running.value = true
        Diag.i("share: screen share started")
        return START_NOT_STICKY
    }

    private fun begin(code: Int, data: Intent): Boolean = try {
        val manager = getSystemService(MediaProjectionManager::class.java)
        val shown = manager.getMediaProjection(code, data) ?: return false
        projection = shown
        val worker = HandlerThread("screen-share").also { it.start() }
        thread = worker
        val handler = Handler(worker.looper)
        // Android 14 needs a callback registered before the virtual display is made.
        shown.registerCallback(
            object : MediaProjection.Callback() {
                override fun onStop() {
                    Handler(Looper.getMainLooper()).post { stopSelf() }
                }
            },
            handler,
        )
        val metrics = resources.displayMetrics
        val scale = minOf(1f, TARGET_WIDTH / metrics.widthPixels.toFloat())
        val width = (metrics.widthPixels * scale).toInt().coerceAtLeast(2)
        val height = (metrics.heightPixels * scale).toInt().coerceAtLeast(2)
        val images = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader = images
        images.setOnImageAvailableListener({ source -> onFrame(source, width, height) }, handler)
        display = shown.createVirtualDisplay(
            "rose-share",
            width,
            height,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            images.surface,
            null,
            handler,
        )
        display != null
    } catch (e: SecurityException) {
        Diag.w("share: refused (${e.javaClass.simpleName})")
        false
    } catch (e: RuntimeException) {
        Diag.w("share: failed (${e.javaClass.simpleName})")
        false
    }

    private fun onFrame(source: ImageReader, width: Int, height: Int) {
        val image = source.acquireLatestImage() ?: return
        try {
            val now = SystemClock.elapsedRealtime()
            if (now - lastFrame < FRAME_MS) return
            lastFrame = now
            val plane = image.planes[0]
            val rowWidth = plane.rowStride / plane.pixelStride
            val full = Bitmap.createBitmap(rowWidth, height, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(plane.buffer)
            val shot = if (rowWidth == width) full else Bitmap.createBitmap(full, 0, 0, width, height).also { full.recycle() }
            val out = ByteArrayOutputStream()
            shot.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
            shot.recycle()
            VoiceSession.get(this).sendFrame(out.toByteArray())
        } catch (e: RuntimeException) {
            Diag.w("share: frame skipped (${e.javaClass.simpleName})")
        } finally {
            image.close()
        }
    }

    private fun notification(): Notification {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(CHANNEL, "Screen share", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this,
            1,
            Intent(this, ScreenShareService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("${Branding.ASSISTANT_NAME} can see your screen")
            .setContentText("Tap Stop to stop sharing.")
            .setOngoing(true)
            .addAction(0, "Stop", stop)
            .build()
    }

    override fun onDestroy() {
        runCatching { display?.release() }
        runCatching { reader?.close() }
        runCatching { projection?.stop() }
        thread?.quitSafely()
        display = null
        reader = null
        projection = null
        _running.value = false
        Diag.i("share: screen share stopped")
        super.onDestroy()
    }

    companion object {
        private const val ACTION_STOP = "app.shilex.android.share.STOP"
        private const val EXTRA_CODE = "code"
        private const val EXTRA_DATA = "data"
        private const val CHANNEL = "screen_share"
        private const val NOTE_ID = 7
        private const val TARGET_WIDTH = 720f
        private const val FRAME_MS = 1_000L
        private const val JPEG_QUALITY = 55

        private val _running = MutableStateFlow(false)

        /** True while the screen is being shared. */
        val running: StateFlow<Boolean> = _running.asStateFlow()

        /** [code] and [data] are what Android's screen-capture permission screen returned. */
        fun start(context: Context, code: Int, data: Intent) {
            context.startForegroundService(
                Intent(context, ScreenShareService::class.java).putExtra(EXTRA_CODE, code).putExtra(EXTRA_DATA, data),
            )
        }

        fun stop(context: Context) {
            if (_running.value) context.stopService(Intent(context, ScreenShareService::class.java))
        }
    }
}
