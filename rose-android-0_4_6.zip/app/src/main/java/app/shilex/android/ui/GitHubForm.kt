package app.shilex.android.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import app.shilex.android.code.GitHubRules
import app.shilex.android.data.KeyVault
import app.shilex.android.data.Settings as AppSettings

/** GitHub repo, work branch and token (kept encrypted), plus the brain and picture model names. */
@Composable
fun GitHubForm() {
    val context = LocalContext.current
    val store = remember { AppSettings(context) }
    val vault = remember { KeyVault(context) }
    var repo by remember { mutableStateOf(store.githubRepo) }
    var branch by remember { mutableStateOf(store.githubBranch) }
    var token by remember { mutableStateOf("") }
    var hasToken by remember { mutableStateOf(!vault.read(KeyVault.GITHUB_TOKEN).isNullOrBlank()) }
    var message by remember { mutableStateOf<String?>(null) }
    var brain by remember { mutableStateOf(store.brainModel) }
    var image by remember { mutableStateOf(store.imageModel) }
    var chatModel by remember { mutableStateOf(store.chatModel) }

    Column(Modifier.padding(vertical = 10.dp)) {
        Text("GitHub", style = MaterialTheme.typography.titleMedium)
        Text(
            "Lets ROSE push the code she writes to ONE repo, on a work branch (never main), start the build and read it. " +
                "Every push and install shows an Allow card first (Phone control must be on). Make a fine-grained token on GitHub for that repo only, " +
                "with Contents, Actions and Workflows set to read and write.",
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
            modifier = Modifier.padding(top = 2.dp),
        )
        OutlinedTextField(
            value = repo,
            onValueChange = { repo = it; message = null },
            label = { Text("Repo (owner/name)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
        )
        OutlinedTextField(
            value = branch,
            onValueChange = { branch = it; message = null },
            label = { Text("Work branch (not main)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
        )
        OutlinedTextField(
            value = token,
            onValueChange = { token = it; message = null },
            label = { Text(if (hasToken) "Token saved: paste a new one to replace" else "Token") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
        )
        message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = Muted, modifier = Modifier.padding(top = 4.dp)) }
        Row {
            TextButton(onClick = {
                val cleanRepo = repo.trim()
                val cleanBranch = branch.trim().ifEmpty { AppSettings.DEFAULT_BRANCH }
                message = when {
                    cleanRepo.isNotEmpty() && !GitHubRules.validRepo(cleanRepo) -> "The repo must look like owner/name."
                    !GitHubRules.validWorkBranch(cleanBranch) -> "That branch name is not allowed (main and master are never used)."
                    else -> {
                        store.githubRepo = cleanRepo
                        store.githubBranch = cleanBranch
                        branch = cleanBranch
                        if (token.isNotBlank()) {
                            vault.write(KeyVault.GITHUB_TOKEN, token.trim())
                            hasToken = true
                            token = ""
                        }
                        "Saved."
                    }
                }
            }) { Text("Save") }
            if (hasToken) {
                TextButton(onClick = {
                    vault.remove(KeyVault.GITHUB_TOKEN)
                    hasToken = false
                    message = "Token removed."
                }) { Text("Remove token") }
            }
        }
        Text("Brain model", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp))
        Text(
            "The bigger Gemini model ROSE asks for coding, plans and prompts, and the model that makes pictures. Plain model names. " +
                "Videos are not made here: ROSE writes the prompt for a video tool.",
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
        )
        OutlinedTextField(
            value = brain,
            onValueChange = { brain = it; if (it.isNotBlank()) store.brainModel = it },
            label = { Text("Brain model") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
        )
        OutlinedTextField(
            value = chatModel,
            onValueChange = { chatModel = it; if (it.isNotBlank()) store.chatModel = it },
            label = { Text("Chat model (text chat screen)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
        )
        OutlinedTextField(
            value = image,
            onValueChange = { image = it; if (it.isNotBlank()) store.imageModel = it },
            label = { Text("Picture model") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
        )
    }
}
