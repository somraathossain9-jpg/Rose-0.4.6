package app.shilex.android.tools

import org.junit.Assert.assertEquals
import org.junit.Test

class BrainRulesTest {
    @Test
    fun codeFencesAreStripped() {
        assertEquals("fun a() {}", BrainTools.stripFence("```kotlin\nfun a() {}\n```"))
        assertEquals("plain", BrainTools.stripFence("  plain  "))
    }
}
