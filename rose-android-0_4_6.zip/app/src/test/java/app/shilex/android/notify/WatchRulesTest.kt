package app.shilex.android.notify

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WatchRulesTest {
    private fun wa(title: String, text: String, group: Boolean = false) =
        Seen("com.whatsapp", "WhatsApp", title, text, 0L, group)

    @Test
    fun aPersonIsNamedAndTheirWordsAreRead() {
        val line = WatchRules().decide(wa("Mom", "Kab aa rahe ho?"), 0L, phoneSilent = false, inConversation = false)
        assertEquals("Mom wrote on WhatsApp: Kab aa rahe ho?", line)
    }

    @Test
    fun aFriendsMessageWithOfferOrDealIsStillAMessage() {
        val line = WatchRules().decide(wa("Rimon", "deal ta final, kal dekha hobe"), 0L, false, false)
        assertTrue(line!!.startsWith("Rimon wrote"))
    }

    @Test
    fun missedCallsAndScamLinksSpeakUp() {
        val call = Seen("com.samsung.android.dialer", "Phone", "Rahul", "Missed call", 0L)
        assertEquals("Missed call from Rahul.", WatchRules().decide(call, 0L, false, false))
        val scam = WatchRules().decide(wa("+91 98765 43210", "Prize! http://bit.ly/x1"), 0L, false, false)
        assertTrue(scam!!.startsWith("Careful"))
        assertFalse(scam.contains("bit.ly"))
    }

    @Test
    fun groupsOffersAndCodesStayQuiet() {
        val rules = WatchRules()
        assertNull(rules.decide(wa("Family", "Ravi: hi", group = true), 0L, false, false))
        assertNull(rules.decide(Seen("in.swiggy.android", "Swiggy", "50% OFF", "deal", 0L), 0L, false, false))
        assertNull(rules.decide(Seen("com.google.android.apps.messaging", "Messages", "HDFC", "OTP is 482913", 0L), 0L, false, false))
    }

    @Test
    fun silentPhoneOrAConversationKeepsItQuiet() {
        assertNull(WatchRules().decide(wa("Mom", "Hi"), 0L, phoneSilent = true, inConversation = false))
        assertNull(WatchRules().decide(wa("Mom", "Hi"), 0L, phoneSilent = false, inConversation = true))
    }

    @Test
    fun everyNewMessageIsAnnouncedAfterAShortGap() {
        val rules = WatchRules()
        assertTrue(rules.decide(wa("Mom", "Hi"), 0L, false, false) != null)
        // Straight after: only the 2 s gap holds it back.
        assertNull(rules.decide(wa("Priya", "Hey"), 1_000L, false, false))
        assertTrue(rules.decide(wa("Priya", "Hey"), WatchRules.GAP_MS + 1, false, false) != null)
        // The same person writing again is announced too.
        assertTrue(rules.decide(wa("Mom", "Hello?"), 2 * WatchRules.GAP_MS + 2, false, false) != null)
    }
}
