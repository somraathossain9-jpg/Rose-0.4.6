package app.shilex.android.code

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CodeRulesTest {
    @Test
    fun pathsStayInsideTheWorkspace() {
        assertEquals("app/src/Main.kt", CodePaths.clean("app/src/Main.kt"))
        assertEquals("app/Main.kt", CodePaths.clean("/app\\Main.kt"))
        assertEquals(".github/workflows/build.yml", CodePaths.clean(".github/workflows/build.yml"))
        assertNull(CodePaths.clean("../secret"))
        assertNull(CodePaths.clean("a/../../b"))
        assertNull(CodePaths.clean(".git/config"))
        assertNull(CodePaths.clean(""))
        assertNull(CodePaths.clean("a//b"))
        assertNull(CodePaths.clean("a/b:c"))
    }

    @Test
    fun neverPushesToTheMainLine() {
        assertTrue(GitHubRules.validWorkBranch("rose-work"))
        assertTrue(GitHubRules.validWorkBranch("rose/fix-1"))
        assertFalse(GitHubRules.validWorkBranch("main"))
        assertFalse(GitHubRules.validWorkBranch("MASTER"))
        assertFalse(GitHubRules.validWorkBranch("a..b"))
        assertFalse(GitHubRules.validWorkBranch("bad branch"))
    }

    @Test
    fun repoAndWorkflowNamesAreChecked() {
        assertTrue(GitHubRules.validRepo("somraat/rose-android"))
        assertFalse(GitHubRules.validRepo("somraat"))
        assertFalse(GitHubRules.validRepo("a/b/c"))
        assertFalse(GitHubRules.validRepo("a/b?x=1"))
        assertTrue(GitHubRules.validWorkflow("build.yml"))
        assertFalse(GitHubRules.validWorkflow("../build.yml"))
    }

    @Test
    fun blobShaMatchesGit() {
        // `printf 'hello\n' | git hash-object --stdin`
        assertEquals("ce013625030ba8dba906f756967f9e9ca394464a", GitHubRules.blobSha("hello\n".toByteArray()))
        assertEquals("100755", GitHubRules.modeFor("gradlew"))
        assertEquals("100644", GitHubRules.modeFor("app/Main.kt"))
    }

    @Test
    fun binaryFilesAreNotCopied() {
        assertFalse(GitHubRules.isText("docs/logo.png"))
        assertFalse(GitHubRules.isText("gradle/wrapper/gradle-wrapper.jar"))
        assertTrue(GitHubRules.isText("app/build.gradle.kts"))
    }

    @Test
    fun logDigestKeepsErrorsAndTheEnd() {
        val log = "2026-11-13T10:00:00.1234567Z starting\n2026-11-13T10:00:01Z e: Foo.kt: Unresolved reference: bar\n" +
            (1..50).joinToString("\n") { "line $it" }
        val digest = GitHubRules.digestLog(log)
        assertTrue(digest.contains("Unresolved reference: bar"))
        assertTrue(digest.contains("line 50"))
        assertFalse(digest.contains("2026-11-13T"))
    }

    @Test
    fun secretsAreNeverWrittenOrPushed() {
        assertTrue(GitHubRules.looksSecret("val t = \"ghp_abcdefghijklmnopqrstuvwxyz0123456789\""))
        assertTrue(GitHubRules.looksSecret("pin = \"4821\""))
        assertTrue(GitHubRules.looksSecret("-----BEGIN RSA PRIVATE KEY-----"))
        assertFalse(GitHubRules.looksSecret("val password = remember { mutableStateOf(\"\") }"))
        assertFalse(GitHubRules.looksSecret("fun main() { println(\"hi\") }"))
    }
}
