# Rose 0.4.6 (self-update that works, chat with tools, speaker and copy, calmer auto reply)

- Self-update fixed at its root: every GitHub build used to get a NEW random debug key, so Android refused each update
  ("package conflicts"). Now one fixed key, app/rose-signing.keystore (alias rose), signs every build (debug and release).
  versionCode = 9 + the GitHub run number, so each build is newer than the one before. IMPORTANT: the first 0.4.6 must be
  installed once by hand after uninstalling the old Rose (the old app has a different key). After that Rose updates herself.
  Note for the repo owner: the keystore and its key are public if the repo is public; that is fine for a personal app, but make the
  repo private if you do not want anybody else to be able to sign an update.
- Chat tab can now update the app: it has the code, GitHub, brain and self tools. New tools: code_replace (change a few lines),
  code_search (find where), github_wait_build (waits for the build, returns the failed step if it failed). code_read can read long
  files in parts (start). Rose's steps: github_pull, code_search/code_read, code_replace, raise versionName, github_push,
  github_wait_build, app_update_install. Each push, pull and install still needs the owner's Allow; in the Chat tab it is an
  Allow dialog (no Phone control needed). The installer chooses the "rose-apk" file (fixed key).
- Chat: Speaker button (reads every new answer aloud, Bangla voice when the phone has one), Listen/Stop and Copy under each message,
  text can be selected, Mic button (speak instead of typing).
- Auto reply: no more repeated asking. A permission the owner said no to is not asked again for 30 minutes; auto_reply_set and
  chat_take_over no longer need an Allow tap (unless screen text was read in the same turn). Saying "auto mode" calls auto_reply_set
  straight away: no questions, no apps, no permissions. In auto mode the phone says who wrote and what, then what Rose answered,
  and also posts a quiet "Auto reply" note on screen (never asks for a permission). More SMS apps are recognised (Xiaomi, Oppo,
  OnePlus, Huawei, Android Messaging...).
- build.yml: builds the APK first and runs the unit tests after it; a newer push cancels an older build.
- Version 0.4.6. Not built or run in the authoring environment: build on GitHub first.

# Rose 0.4.3 (code, GitHub, chat, screen share)

- Languages: Hindi and Hinglish are gone. Rose speaks and writes Bangla (default), Banglish or English; speech recognition is
  bn-IN and en-IN, so what you say shows up in Bangla. Old "hindi/hinglish/auto" settings become Bangla.
- Playful English lines (Settings, on by default): now and then one short English line of fun dialogue that Rose makes up
  from what you just said. Never in serious or task moments.
- Talking over a reply: quicker (voice level 500, 1 chunk with the canceller, spike detector 200 ms). Still depends on the phone.
- Code workspace (tools code_write, code_read, code_list, code_delete, code_zip): Rose writes files in a private folder and
  saves zips to Downloads/Rose. Files that look like keys, tokens, PINs, OTPs or passwords are refused.
- GitHub (Settings > Code, GitHub and brain): one repo, work branch (never main/master), token in the Keystore vault.
  Tools github_push, github_pull, github_run_build, github_build_status, github_build_log, github_read_file,
  app_update_install. Push, pull, build and install each show an Allow card first (Phone control must be on). Repo and
  build-log text counts as outside text (TurnTrust). Installing needs the same signing key as the installed app.
- Brain (brain_ask, brain_image): a bigger Gemini model for code, plans and image/video prompts, and a picture model
  (saved to Pictures/Rose). It sees your saved notes. It cannot make videos.
- Self report (report_limit, self_check): Rose says what she cannot do, which permissions are missing and her known
  weaknesses, and asks "update kore dibo?". An update only starts after you say yes.
- Chat tab: text chat with pictures, screenshots (delayed, needs Phone control) and short videos (up to 14 MB); share a
  picture or video to Rose from the gallery and it opens the chat.
- Live screen share (Home): Android asks every time, a notification shows while it runs, one small picture per second goes
  to Gemini during a conversation, and it stops when the conversation ends.
- Home shows the app version small beside the name (read from the app itself).
- build.yml: runs unit tests (a failure does not stop the APK, the report is saved), builds the debug APK (rose-apk), and builds a
  signed release APK (rose-apk-release) when the secrets KEYSTORE_BASE64 and KEYSTORE_PASSWORD (alias "jarvis") exist.
- Version 0.4.3 (versionCode 6). Not built or run in the authoring environment: build on GitHub first.

# Rose 0.4.1 (messages never missed, talk-over fix)

- Messages are read out at once, with the name and the words ("X লিখেছেন: …"):
  - Fixed: a friend's message that merely contained "offer", "deal", "sale", "free delivery"... was treated as an advert and
    skipped silently. Promo words now silence only non-chat apps (Notify/Triage).
  - Fixed: the same words sent twice ("ok", "ok") were dropped as a repeat; a newer message line now always counts.
  - Ask mode: the phone's own voice reads the message first (no waiting for Gemini to connect); the conversation then starts
    and only asks what to reply. While you are already talking with Rose she now says the new message inside the
    conversation, instead of keeping it for later.
  - A chat with no Reply box (some Instagram / TikTok chats) is read out too, though it can't be answered.
  - The sender's name is taken from the last message when an app titles the chat "2 new messages" or leaves it empty.
  - "Watch my messages" now says what they wrote and no longer waits 10 minutes per person (2 s between messages).
  - After Rose answers a chat she says what she sent ("আমি উত্তর দিয়েছি: …").
  - Instagram Lite, TikTok, Snapchat, Discord, Skype and LINE are recognised as chat apps.
- Talking over a reply (audio/TalkOver): the echo canceller never "learned" on some phones, and then talking over did
  nothing. Until it has, a voice is now also recognised by its level (the mic suddenly well above the echo, for 300 ms),
  so Rose goes quiet when you speak, also on the loudspeaker.
- Songs (tools/MediaTools): "youtube" opens the official YouTube app, "phone_player" the music player on the phone; the
  browser is only the last fallback.
- Version 0.4.1.

# Rose 0.4.0 (message modes update)

- Busy mode no longer stays silent on ok, thanks or emoji: "ok" gets "ওকে", thanks gets "ধন্যবাদ", an emoji gets a fitting
  emoji (and, from the chat so far, a few words: sad gets "কী হয়েছে?"). To stop endless ok-ok, a second closing message
  right after such an answer gets none; a real message resets it. Spam, bots and abuse are still skipped.
- Ask mode can hand ONE chat over: after Rose reads a message out, say "tumi kotha bolo" (or "tumi reply dao") and she
  answers that person herself, also their later messages, and says out loud what they wrote ("X লিখেছেন: …", then
  "আমি উত্তর দিয়ে দিয়েছি।") instead of asking again. Other people are still asked about first. New tool chat_take_over
  (also by name, with an optional note, and release=true to take the chat back). Hand-overs are kept in memory, end after
  12 hours, and are cleared when the mode changes to Off or Auto.
- Auto (busy) mode reads each message out first, then answers. Nothing is spoken on silent or vibrate or while Rose is
  already talking with you.
- Faster message handling: the phone's voice is started ahead of time (the first spoken line no longer waits for the
  engine), a burst of messages waits 0.7 s (was 1.2 s) and the backup model starts after 1.5 s (was 2.5 s).
- The settings text for Messages describes the three modes.

# Rose 0.4.0

- New face and logo: the glowing particle sphere (see docs/logo.png). The orb is now thousands of dots on a turning
  sphere with a bright rim and folding ribbons of light; it swells with the voice and moves most while speaking.
  New launcher icon (adaptive, with a themed monochrome version). Default colour is magenta/violet.
- 33 moods (was 20): romantic, dreamy, playful, focused, serious, energetic, peaceful, mysterious, brave, hopeful,
  lonely, magical, sweet added. The orb takes its colours from the mood.
- Notifications are seen sooner: a 15-minute watchdog (Notify/Watchdog) rebinds notification access when Android drops
  it, messages that arrived while access was down are answered on reconnect (busy mode, last 30 min), chat
  notifications are read line by line (all new messages, not only the last), more chat apps are recognised
  (Messenger Lite, imo, Viber, Signal, Telegram X), and the lag of each message is written to the diagnostic log.
- Smarter busy-mode replies (notify/AutoReply, AutoReplyRules):
  - Fixed: replies could be cut off or empty because the model's "thinking" used the output budget. Thinking is now off.
  - A burst of messages gets one answer (1.2 s wait), not one per message.
  - The model chooses: reply, stay silent (thanks, ok, emoji, bots, spam) or urgent (replies and alerts you with a
    notification and a spoken line). It sees the time, whether the sender is a saved contact, how the chat went and when
    it last replied, so it does not repeat itself or re-introduce itself.
  - Understands voice messages and photos, asks, money/code/link requests, and answers in the sender's language and tone.
  - Faster: models race (the next starts after 2.5 s if the first is slow); a stuck call is cancelled.
  - A code guard refuses any reply with a link, a long number, or talk of OTP/passwords/bKash/Nagad; a safe line is sent
    instead. Busy mode still never answers groups, codes or links.
  - Busy-mode replies now appear in Activity with a few words on what the person wanted.
- bKash, Nagad and Upay apps are blocked from phone control like banking apps.

# Rose 0.3.0

- Long-term memory: notes kept up to 2000 (was 200), the latest 40 are given to Rose at the start of every
  conversation, she saves lasting facts by herself, and never deletes anything unless told to forget it.
- Messages from people (Settings -> Messages): "Ask me" reads each message out and asks whether to reply
  (the spoken yes is still checked by the phone); "Auto (busy)" answers people by itself as the owner's
  assistant, keeps chatting (Gemini writes each reply), max 8 replies an hour per chat, never groups, codes or links.
  The tool auto_reply_set lets you switch it by voice ("tumi reply dite thako").
- Faster message alerts: the notification listener rebinds itself when Android drops it, and the app asks once
  to be excluded from battery optimisation.
- Bangla is the default reply language (Bangladeshi Bangla); the Bangla voice reads messages aloud.
- Persona: Rose is a girl character and a caring friend; owner name is Somraat Islam Srabon.

# Changes since the Jarvis -> Rose rename

- Voice picker (female voices first, default Kore), reply language incl. Bangla/Banglish, model name field (Settings).
- Bangla (bn-IN) added to speech recognition, so what you say appears in Bangla script.
- Talk over reacts sooner (TalkOver quick settings in VoiceSession).
- "Send and call without asking" (default off): only plain Send/Call in messaging apps and the dialer
  (ControlRules.autoAllowed). Payments, delete, OTP, passwords and banking apps still need you.
- Friendly mode: jokes, playful arguments, calls the owner Boss / Samrat Boss / Shrabon / Sir.
- 20 moods (assistant/Mood.kt) via the silent set_mood tool; the orb changes colour and has a 3D look (ui/Orb.kt).
- Instructions v9: careful listening and checking each tool result.
